# 🌐 MULTI-SOURCE COLLECTION SYSTEM

Sistema completo de agregação de dados de múltiplas fontes para Lorcana AI.

---

## 📦 COMPONENTES

### **1. DreamBorn API Client** (`dreamborn-api.js`)
- ✅ Busca dados oficiais de cartas
- ✅ API pública: https://api.lorcana-api.com
- ✅ Retry automático com exponential backoff
- ✅ Normalização de dados

### **2. Melee.gg Scraper** (`melee-scraper.js`)
- ✅ Scraper com User-Agent rotation
- ✅ Bypass de bloqueios
- ✅ Rate limiting respeitoso
- ✅ Extração de decklists de torneios

### **3. Source Aggregator** (`source-aggregator.js`)
- ✅ Unifica dados de todas as fontes
- ✅ Deduplicação por fingerprint SHA256
- ✅ Merge de duplicatas (mantém melhor placement)
- ✅ Normalização cross-source

### **4. Multi-Source Collector** (`multi-source-collector.js`)
- ✅ Orquestrador principal
- ✅ Pipeline completo de coleta
- ✅ CLI intuitivo

---

## 🚀 INSTALAÇÃO

### **Passo 1: Copiar Arquivos**

```powershell
cd S:\INKREC\lorcana_ai

# Copiar todos os arquivos
copy dreamborn-api.js backend\services\scrapers\
copy melee-scraper.js backend\services\scrapers\
copy source-aggregator.js backend\services\scrapers\
copy multi-source-collector.js backend\services\scrapers\

# Copiar inkdecks-scraper-v2.js se ainda não tiver
copy inkdecks-scraper-v2.js backend\services\scrapers\
```

### **Passo 2: Criar Diretórios**

```powershell
cd backend
mkdir data -Force
mkdir db -Force
```

---

## ⚡ USO RÁPIDO

### **Coleta Completa (Recomendado)**

```powershell
cd backend\services\scrapers
node multi-source-collector.js collect
```

**Isso vai:**
1. ✅ Atualizar database de cartas (DreamBorn)
2. ✅ Coletar 100 decks do inkDecks
3. ✅ Coletar 10 torneios do Melee.gg
4. ✅ Agregar e deduplic ar tudo

**Tempo:** ~5-10 minutos

---

## 📋 COMANDOS DISPONÍVEIS

### **1. Coleta Completa**
```powershell
node multi-source-collector.js collect
```

### **2. Apenas Cards (DreamBorn)**
```powershell
node multi-source-collector.js cards
```

### **3. Apenas inkDecks**
```powershell
node multi-source-collector.js inkdecks
```

### **4. Apenas Melee.gg**
```powershell
node multi-source-collector.js melee
```

### **5. Apenas Agregação**
```powershell
node multi-source-collector.js aggregate
```

### **6. Help**
```powershell
node multi-source-collector.js help
```

---

## 🎛️ OPÇÕES AVANÇADAS

### **Pular Fontes Específicas**

```powershell
# Pular Melee.gg (se estiver bloqueando)
node multi-source-collector.js collect --skip-melee

# Pular inkDecks
node multi-source-collector.js collect --skip-inkdecks

# Pular atualização de cards
node multi-source-collector.js collect --skip-cards
```

### **Forçar Atualização de Cards**

```powershell
# Mesmo que database seja recente
node multi-source-collector.js collect --force-cards
```

### **Combinar Opções**

```powershell
# Só inkDecks + Cards, sem Melee
node multi-source-collector.js collect --skip-melee
```

---

## 📂 ESTRUTURA DE ARQUIVOS

Após execução, você terá:

```
backend/
├── db/
│   ├── cards.json              ← Database de cartas (DreamBorn)
│   └── cards.meta.json         ← Metadados
├── data/
│   ├── tournamentMeta.json     ← Dados do inkDecks
│   ├── melee.json              ← Dados do Melee.gg
│   ├── aggregated.json         ← ✨ DADOS UNIFICADOS
│   └── aggregated.stats.json   ← Estatísticas
└── services/
    └── scrapers/
        ├── dreamborn-api.js
        ├── melee-scraper.js
        ├── source-aggregator.js
        ├── multi-source-collector.js
        └── inkdecks-scraper-v2.js
```

---

## 🔍 ENTENDENDO O OUTPUT

### **aggregated.json**

```json
{
  "decks": [
    {
      "id": "deck123",
      "name": "Sapphire Steel Control",
      "author": "John Doe",
      "cards": [...],
      "tournament": {
        "name": "Regional 2024",
        "placement": 1,
        "date": "2024-02-15"
      },
      "source": "inkdecks",
      "sources": ["inkdecks", "melee"],  ← Múltiplas fontes!
      "fingerprint": "a1b2c3...",
      "duplicates": 2  ← Encontrado em 3 lugares
    }
  ],
  "stats": {
    "sources": {
      "inkdecks": 100,
      "melee": 50
    },
    "total": 150,
    "unique": 120,     ← Após deduplicação
    "duplicates": 30,
    "merged": 120
  }
}
```

---

## 📊 DEDUPLICAÇÃO

### **Como Funciona?**

1. **Fingerprint SHA256**
   - Cada deck gera um hash único baseado nas cartas
   - Ordem não importa: `4 Hades + 3 Mulan` = `3 Mulan + 4 Hades`

2. **Identificação de Duplicatas**
   - Decks com mesmo fingerprint = duplicata
   - Mantém o de melhor placement

3. **Merge Inteligente**
   - Combina informações de múltiplas fontes
   - Preserva histórico de placements

### **Exemplo:**

**Antes:**
```
inkDecks:  Deck A (placement: 2)
Melee:     Deck A (placement: 1)  ← Mesmo deck!
```

**Depois (merged):**
```
Deck A:
  source: "inkdecks"
  sources: ["inkdecks", "melee"]
  placement: 1  ← Melhor placement
  duplicates: 1
  allPlacements: [
    { source: "inkdecks", placement: 2 },
    { source: "melee", placement: 1 }
  ]
```

---

## 🔧 TROUBLESHOOTING

### **Erro: Melee.gg retorna 403**

**Problema:** Melee.gg está bloqueando

**Soluções:**
1. Usar `--skip-melee` por enquanto
2. Ajustar User-Agents em `melee-scraper.js`
3. Aumentar delays entre requests
4. Tentar novamente mais tarde

```powershell
# Continuar sem Melee
node multi-source-collector.js collect --skip-melee
```

---

### **Erro: DreamBorn API timeout**

**Problema:** API lenta ou indisponível

**Soluções:**
1. Tentar novamente (retry automático)
2. Verificar internet
3. Usar `--skip-cards` e usar database antiga

```powershell
# Usar database existente
node multi-source-collector.js collect --skip-cards
```

---

### **Erro: inkDecks não responde**

**Problema:** Site fora do ar ou bloqueando

**Soluções:**
1. Ajustar delays em `inkdecks-scraper-v2.js`
2. Reduzir `maxDecks`
3. Verificar se site está online

```powershell
# Testar apenas inkDecks
node multi-source-collector.js inkdecks
```

---

## 📈 OTIMIZAÇÕES

### **Ajustar Limites**

Editar `multi-source-collector.js`:

```javascript
const CONFIG = {
  // ...
  inkdecksMax: 200,        // ← Aumentar de 100
  meleeMaxTournaments: 20, // ← Aumentar de 10
};
```

### **Cache de Cards**

Cards são cached por 24h. Para forçar update:

```powershell
node multi-source-collector.js cards --force
```

---

## 🤖 AUTOMAÇÃO

### **Cron Job (Linux)**

```bash
# Rodar diariamente às 3am
0 3 * * * cd /path/to/lorcana_ai/backend/services/scrapers && node multi-source-collector.js collect --skip-melee > /tmp/lorcana-collect.log 2>&1
```

### **Task Scheduler (Windows)**

1. Abrir Task Scheduler
2. Create Task
3. Trigger: Daily 3:00 AM
4. Action: Run `node multi-source-collector.js collect`
5. Start in: `S:\INKREC\lorcana_ai\backend\services\scrapers`

---

## 📊 INTEGRAÇÃO COM BACKEND

### **Usar Dados Agregados**

```javascript
// Em routes/meta.js ou similar

const fs = require('fs');
const aggregatedPath = './backend/data/aggregated.json';

function loadMetaData() {
  if (!fs.existsSync(aggregatedPath)) {
    return { decks: [], stats: {} };
  }
  
  const data = fs.readFileSync(aggregatedPath, 'utf8');
  return JSON.parse(data);
}

// Usar no endpoint
app.get('/api/meta/decks', (req, res) => {
  const meta = loadMetaData();
  res.json(meta);
});
```

---

## 🎯 ROADMAP

### **Fase Atual: v5.5**
- ✅ DreamBorn API
- ✅ Melee.gg scraper
- ✅ Agregação multi-source
- ✅ Deduplicação
- ⬜ Lorcana Lair scraper
- ⬜ Start.gg API

### **Próximas Fases:**
- **v6.0:** Integração oficial Ravensburger
- **v7.0:** TO Tools
- **v8.0:** ML Analytics

---

## 💡 DICAS

1. **Começe Devagar**
   - Teste com `--skip-melee` primeiro
   - Aumente limites gradualmente

2. **Monitore Logs**
   - Sempre revise output
   - Procure por `❌` errors

3. **Respeite Rate Limits**
   - Não abuse dos sites
   - Ajuste delays se necessário

4. **Backup**
   - Faça backup de `aggregated.json`
   - Útil para rollback

5. **Update Regular**
   - Rode diariamente
   - Mantenha dados frescos

---

## 📞 SUPORTE

**Problemas Comuns:**
- Ver seção Troubleshooting acima
- Verificar logs
- Testar componentes individualmente

**Testar Individualmente:**

```powershell
# Test DreamBorn
node dreamborn-api.js build

# Test inkDecks
node inkdecks-scraper-v2.js --max 5

# Test Melee
node melee-scraper.js tournaments 1

# Test Aggregation
node source-aggregator.js aggregate
```

---

## ✅ CHECKLIST DE INSTALAÇÃO

- [ ] Copiei todos os arquivos .js
- [ ] Criei diretórios `data` e `db`
- [ ] Testei `node multi-source-collector.js help`
- [ ] Rodei primeira coleta com sucesso
- [ ] Verifiquei `aggregated.json` criado
- [ ] Configurei automação (opcional)

---

## 🎉 PRONTO!

Seu sistema multi-source está configurado e funcionando!

**Próximos passos:**
1. Rodar coleta completa
2. Integrar `aggregated.json` no backend
3. Exibir dados no frontend
4. Configurar automação

**Execute agora:**

```powershell
cd S:\INKREC\lorcana_ai\backend\services\scrapers
node multi-source-collector.js collect
```

**Boa sorte!** 🚀✨
