# 🗺️ MASTER PLAN - Lorcana AI

## 🎯 VISÃO

Criar a **plataforma definitiva** para análise, meta tracking e tournament management de Disney Lorcana TCG.

---

## 📊 STATUS ATUAL (v4.3)

### **✅ Funcionalidades Implementadas**

| Feature | Status | Qualidade |
|---------|--------|-----------|
| Deck Analyzer | ✅ Funcionando | ⭐⭐⭐ Bom |
| Hand Analyzer | ✅ Funcionando | ⭐⭐ Básico |
| Matchups | ✅ Funcionando | ⭐⭐⭐ Bom |
| Meta Dashboard | ✅ Funcionando | ⭐⭐⭐⭐⭐ Excelente |
| Tournament Scraper | ✅ Funcionando | ⭐⭐⭐ Bom |
| Meta Analyzer | ✅ Funcionando | ⭐⭐⭐⭐ Muito Bom |

### **✅ Dados Atuais**
- 333 decks de torneios
- 1 fonte ativa (inkDecks)
- 263 arquétipos detectados
- Update manual

---

## 🚀 ROADMAP COMPLETO

### **FASE 1: ENHANCEMENTS (v4.3 → v5.0)** 
**Prazo:** 1-2 semanas  
**Status:** 🟡 Em Andamento

#### **Objetivos:**
- ✅ Deck Analyzer com curva de ink
- ✅ Mulligan advisor inteligente
- ✅ Scraper robusto v2
- ⬜ Testes e validação
- ⬜ Deploy das melhorias

#### **Entregáveis:**
1. ✅ DeckAnalyzer-ENHANCED.jsx
2. ✅ mulliganAdvisor-SMART.js
3. ✅ inkdecks-scraper-v2.js
4. ⬜ Testes E2E
5. ⬜ Documentação usuário

#### **Métricas de Sucesso:**
- Curva de ink funciona 100%
- Mulligan accuracy >70%
- Scraper coleta 50+ decks/dia
- Zero bugs críticos

---

### **FASE 2: MULTIPLE SOURCES (v5.0 → v5.5)**
**Prazo:** 2-4 semanas  
**Status:** 📋 Planejado

#### **Objetivos:**
- ⬜ Integrar DreamBorn API
- ⬜ Bypass Melee.gg (User-Agent rotation)
- ⬜ Scraper Lorcana Lair
- ⬜ Agregador de múltiplas fontes
- ⬜ Deduplicação cross-source

#### **Entregáveis:**
1. `dreamborn-scraper.js`
2. `melee-scraper.js`
3. `lorcana-lair-scraper.js`
4. `source-aggregator.js`
5. Dashboard de fontes (admin)

#### **Arquitetura:**
```
┌─────────────────────────────────────────┐
│         Source Aggregator               │
│  - Normalização                         │
│  - Deduplicação                         │
│  - Priorização                          │
└─────────────────────────────────────────┘
         ↓            ↓            ↓
   ┌─────────┐  ┌──────────┐  ┌─────────┐
   │inkDecks │  │DreamBorn │  │Melee.gg │
   └─────────┘  └──────────┘  └─────────┘
```

#### **Métricas de Sucesso:**
- 3+ fontes ativas
- 500+ decks no DB
- Update automático diário
- <5% duplicação

---

### **FASE 3: RAVENSBURGER INTEGRATION (v5.5 → v6.0)**
**Prazo:** 1-2 meses  
**Status:** 📋 Planejado

#### **Objetivos:**
- ⬜ Investigar API Ravensburger
- ⬜ Contatar developer relations
- ⬜ Implementar read-only integration
- ⬜ Sync automático de torneios oficiais
- ⬜ Certificação oficial (se possível)

#### **Entregáveis:**
1. `ravensburger-api.js`
2. `ravensburger-scraper.js` (fallback)
3. `ravensburger-normalizer.js`
4. Sync automático (webhook ou cron)
5. Badge "Official Data Partner"

#### **Workflow:**
```
Ravensburger
    ↓
  [API/Webhook]
    ↓
Lorcana AI DB
    ↓
Meta Dashboard
```

#### **Métricas de Sucesso:**
- API key obtida OU scraper funcional
- 100% coverage de torneios oficiais
- Latência < 24h
- Zero violações de ToS

---

### **FASE 4: TOURNAMENT ORGANIZER TOOLS (v6.0 → v7.0)**
**Prazo:** 2-3 meses  
**Status:** 💡 Conceito

#### **Objetivos:**
- ⬜ Sistema de pairings (Swiss)
- ⬜ Bracket de top cut
- ⬜ Timer automático
- ⬜ Decklist submission
- ⬜ Export para Ravensburger
- ⬜ PDF reports

#### **Entregáveis:**
1. TO Dashboard
2. Pairing engine
3. Timer system
4. Decklist validator
5. Export system
6. Mobile companion app (check-in)

#### **User Personas:**

**Tournament Organizer:**
- Create event
- Add players
- Run swiss rounds
- Cut to top 8
- Export results
- Print standings

**Player:**
- Register for event
- Submit decklist
- View pairings
- Report results
- See standings

#### **Arquitetura:**
```
┌─────────────────────────────────┐
│      TO Dashboard (Web)         │
│  - Event creation               │
│  - Player management            │
│  - Pairing generation           │
│  - Results tracking             │
└─────────────────────────────────┘
         ↓                 ↓
┌──────────────┐    ┌──────────────┐
│Player App    │    │Export System │
│(Mobile)      │    │- Ravensburger│
│- Check-in    │    │- PDF         │
│- Pairings    │    │- Excel       │
│- Results     │    └──────────────┘
└──────────────┘
```

#### **Métricas de Sucesso:**
- 10+ TOs usando o sistema
- 100+ eventos gerenciados
- <1min para gerar pairings
- Zero erros de bracket

---

### **FASE 5: ADVANCED ANALYTICS (v7.0 → v8.0)**
**Prazo:** 3-4 meses  
**Status:** 💡 Conceito

#### **Objetivos:**
- ⬜ ML para predição de meta
- ⬜ Card win rate tracking
- ⬜ Archetype matchup matrix
- ⬜ Historical meta trends
- ⬜ Player performance tracking
- ⬜ ELO/Rating system

#### **Entregáveis:**
1. Meta prediction model
2. Card win rate dashboard
3. Matchup matrix (real data)
4. Time series analysis
5. Player rankings
6. Tournament tier system

#### **Features Detalhadas:**

**Meta Prediction:**
```python
# ML model para prever próximo meta
Input: Últimos 30 dias de torneios
Output: Top 10 archetypes próximos 7 dias
Accuracy target: >60%
```

**Card Win Rates:**
```
Hades - Infernal Schemer
- Overall WR: 54.2%
- In Blurple: 56.8%
- In Ruby/Amethyst: 51.3%
- Best with: Tipo, Goliath
- Worst against: Steel Songs
```

**Historical Trends:**
```
Set 11 Meta Evolution:
Week 1: Blurple 35%, Ruby 25%, Sapphire 15%
Week 2: Blurple 32%, Ruby 28%, Sapphire 18%
Week 3: Blurple 28%, Ruby 30%, Sapphire 20%
→ Trending: Ruby ↗, Blurple ↘
```

#### **Métricas de Sucesso:**
- ML model com 60%+ accuracy
- Win rate data para 100+ cartas
- Historical data de 6+ meses
- Player rankings ativo

---

### **FASE 6: MOBILE APP (v8.0 → v9.0)**
**Prazo:** 4-6 meses  
**Status:** 💡 Conceito

#### **Objetivos:**
- ⬜ React Native app
- ⬜ Offline mode
- ⬜ Camera deck scan
- ⬜ Push notifications
- ⬜ Tournament finder
- ⬜ Social features

#### **Entregáveis:**
1. iOS app
2. Android app
3. Camera OCR
4. Offline database
5. Push notification system
6. Social feed

#### **Features Core:**

**Deck Scanner:**
```
1. User takes photo of decklist
2. OCR recognizes cards
3. Auto-format to 4x Nome
4. One-tap analyze
```

**Tournament Finder:**
```
Map view of nearby tournaments
Filter by:
- Distance
- Date
- Format
- Prize support
```

**Notifications:**
```
- New meta report available
- Your archetype win rate changed
- Nearby tournament tomorrow
- Friend posted deck
```

#### **Métricas de Sucesso:**
- 1000+ downloads
- 4.5+ rating
- 50% weekly active users
- <3% crash rate

---

### **FASE 7: MONETIZATION & SCALE (v9.0+)**
**Prazo:** 6-12 meses  
**Status:** 💡 Conceito

#### **Objetivos:**
- ⬜ Freemium model
- ⬜ Premium features
- ⬜ TO subscription
- ⬜ Ads (não intrusivos)
- ⬜ Partnerships
- ⬜ Scale infrastructure

#### **Revenue Streams:**

**Free Tier:**
- Basic deck analyzer
- Meta dashboard (last 30 days)
- Hand analyzer (limited)
- 10 analyses/day

**Premium ($4.99/month):**
- Unlimited analyses
- Historical meta (all time)
- Advanced mulligan AI
- Priority support
- Ad-free
- Export features

**TO Pro ($19.99/month):**
- Tournament management
- Unlimited events
- Export to Ravensburger
- Custom branding
- Player database
- Email support

**Enterprise (Custom):**
- White label
- API access
- Dedicated support
- Custom integrations

#### **Partnerships:**
- LGS (Local Game Stores)
- Content creators
- Tournament organizers
- Ravensburger official

#### **Métricas de Sucesso:**
- 1000+ free users
- 100+ premium subscribers
- 10+ TO Pro subscribers
- $2000+ MRR (Monthly Recurring Revenue)

---

## 🎯 MILESTONES

### **2026 Q1 (Fev-Mar)**
- ✅ v4.3 stable
- ⬜ v5.0 enhancements live
- ⬜ 500+ decks in DB

### **2026 Q2 (Abr-Jun)**
- ⬜ v6.0 with Ravensburger
- ⬜ 3+ data sources
- ⬜ 2000+ decks in DB

### **2026 Q3 (Jul-Set)**
- ⬜ v7.0 with TO tools
- ⬜ 10+ TOs using platform
- ⬜ Beta mobile app

### **2026 Q4 (Out-Dez)**
- ⬜ v8.0 with ML analytics
- ⬜ Mobile app launch
- ⬜ 5000+ users

### **2027 Q1 (Jan-Mar)**
- ⬜ v9.0 monetization
- ⬜ 100+ paying users
- ⬜ Profitable

---

## 📊 KPIs (Key Performance Indicators)

### **User Metrics:**
- Monthly Active Users (MAU)
- Daily Active Users (DAU)
- Retention rate (D1, D7, D30)
- Session duration
- Analyses per user

### **Data Metrics:**
- Total decks in DB
- Data sources active
- Update frequency
- Data accuracy
- Coverage %

### **Technical Metrics:**
- API response time (<1s)
- Uptime (>99.9%)
- Error rate (<0.1%)
- Mobile crash rate (<3%)

### **Business Metrics:**
- Monthly Recurring Revenue (MRR)
- Customer Acquisition Cost (CAC)
- Lifetime Value (LTV)
- Churn rate (<5%)
- Net Promoter Score (NPS >50)

---

## 🛠️ TECH STACK EVOLUTION

### **Current (v4.3):**
```
Frontend: React
Backend: Node.js + Express
Database: JSON files
Hosting: Local
```

### **Near Future (v5-6):**
```
Frontend: React + TypeScript
Backend: Node.js + Express
Database: PostgreSQL
Hosting: Vercel + Railway
CI/CD: GitHub Actions
```

### **Long Term (v7+):**
```
Frontend: React + Next.js
Mobile: React Native
Backend: Node.js microservices
Database: PostgreSQL + Redis
ML: Python + TensorFlow
Hosting: AWS/GCP
CDN: Cloudflare
Monitoring: DataDog
```

---

## 🎓 TEAM EXPANSION

### **Phase 1 (Solo):**
- Current: 1 developer (você)
- Focus: Core features

### **Phase 2 (Small Team):**
- Backend dev (1)
- Frontend dev (1)
- Designer (part-time)

### **Phase 3 (Full Team):**
- Backend devs (2)
- Frontend devs (2)
- Mobile dev (1)
- ML engineer (1)
- Designer (1)
- Product manager (1)
- Marketing (part-time)

---

## 💡 INNOVATION IDEAS (Futuro Distante)

### **AI Features:**
- AI deck builder
- AI opponent simulation
- Voice assistant
- Image recognition (card photos)

### **Social Features:**
- Friend system
- Deck sharing
- Tournament replays
- Streaming integration

### **Gamification:**
- Achievement system
- Leaderboards
- Season passes
- Profile badges

### **Content:**
- Meta reports (weekly)
- Deck guides
- Video tutorials
- Podcast

---

## ⚠️ RISKS & MITIGATION

### **Legal Risks:**
- **Risk:** Ravensburger C&D
- **Mitigation:** Usar apenas dados públicos, atribuir fontes, seguir fair use

### **Technical Risks:**
- **Risk:** Scraping bloqueado
- **Mitigation:** Múltiplas fontes, APIs oficiais, rate limiting

### **Business Risks:**
- **Risk:** Baixa adoção
- **Mitigation:** Marketing, community engagement, free tier generoso

### **Competition Risks:**
- **Risk:** Competitor melhor
- **Mitigation:** Inovação constante, escutar usuários, qualidade superior

---

## 🎯 NORTH STAR METRIC

**"Número de decks analisados por semana"**

Essa métrica indica:
- Engagement dos usuários
- Utilidade da plataforma
- Crescimento orgânico
- Product-market fit

**Target:**
- Q1 2026: 100 analyses/week
- Q2 2026: 500 analyses/week
- Q3 2026: 2000 analyses/week
- Q4 2026: 10000 analyses/week

---

## 📝 CONCLUSÃO

Este é um projeto **ambicioso mas viável**. Com foco em:

1. ✅ **Qualidade** sobre quantidade
2. ✅ **Comunidade** no centro
3. ✅ **Dados confiáveis**
4. ✅ **Inovação constante**
5. ✅ **Sustentabilidade**

**Próximos passos imediatos:**
1. Implementar melhorias v5.0 (esta semana)
2. Coletar feedback dos usuários
3. Iterar baseado em dados
4. Planejar v5.5

---

**Status:** 🟢 Active Development  
**Última atualização:** 2026-02-19  
**Versão:** 1.0  
**Mantido por:** Lorcana AI Team

**Let's build the future of Lorcana! 🚀**
