# 🏆 FONTES DE DADOS DE TORNEIOS

## 📋 VISÃO GERAL

Este documento lista **todas as fontes confiáveis** de dados de torneios Lorcana, com análise de viabilidade, prioridade e estratégia de integração.

---

## 🎯 FONTES OFICIAIS (Prioridade Máxima)

### **1. play.ravensburger.com** ⭐⭐⭐⭐⭐

**Status:** Oficial Ravensburger  
**Viabilidade:** Alta (se API disponível) / Média (se scraping)  
**Prioridade:** 🔴 MÁXIMA

**Dados disponíveis:**
- ✅ Resultados de torneios oficiais
- ✅ Standings completos
- ✅ Informações de jogadores
- ✅ Formatos oficiais
- ✅ Datas e locais
- ⚠️ Decklists (nem sempre públicas)

**Estratégias de integração:**

#### **Opção A: API Oficial (Ideal)**
```javascript
// Se Ravensburger fornecer API
const response = await fetch('https://api.ravensburger.com/lorcana/tournaments', {
  headers: {
    'Authorization': 'Bearer YOUR_API_KEY'
  }
});
```

**Vantagens:**
- Dados oficiais e confiáveis
- Rate limits claros
- Suporte oficial
- Legalidade garantida

**Desvantagens:**
- Precisa aprovar API key
- Pode ter limitações
- Custos possíveis

#### **Opção B: RSS Feed**
```javascript
// Se disponível feed RSS
const feed = await fetchRSS('https://play.ravensburger.com/lorcana/feed.rss');
```

#### **Opção C: Scraping Responsável**
```javascript
// Último recurso
const tournaments = await scrapePage('https://play.ravensburger.com/lorcana/tournaments');
```

**Como investigar:**
1. Verificar documentação pública
2. Contatar Ravensburger Developer Relations
3. Verificar se há Terms of Service para scraping
4. Analisar headers/requests no DevTools

**Contato sugerido:**
- Email: developer@ravensburger.com (verificar se existe)
- Formulário de contato no site oficial
- Twitter @Ravensburger
- Discord oficial Lorcana

---

### **2. Melee.gg** ⭐⭐⭐⭐

**Status:** Plataforma oficial de TO (Tournament Organizer)  
**Viabilidade:** Média (bloqueio de User-Agent)  
**Prioridade:** 🟠 ALTA

**Dados disponíveis:**
- ✅ Resultados de torneios
- ✅ Standings
- ✅ Decklists (às vezes)
- ✅ Player stats
- ✅ Event details

**URL base:** `https://melee.gg`

**Problema atual:**
```
HTTP 403 - User-Agent blocked
```

**Soluções:**

#### **Solução 1: Rotating User-Agents**
```javascript
const userAgents = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36...',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)...',
  'Mozilla/5.0 (X11; Linux x86_64)...',
];

function getRandomUserAgent() {
  return userAgents[Math.floor(Math.random() * userAgents.length)];
}
```

#### **Solução 2: Proxy Rotation**
```javascript
const proxies = ['proxy1:8080', 'proxy2:8080'];
// Rodar requests por diferentes proxies
```

#### **Solução 3: Melee.gg API (se disponível)**
- Investigar se existe API pública ou parceira
- Contatar Melee.gg para parceria

**Rate limiting recomendado:**
- 1 request / 3-5 segundos
- Máximo 100 requests / hora
- Respeitar robots.txt

---

## 🌐 FONTES COMUNITÁRIAS (Prioridade Alta)

### **3. inkDecks.com** ⭐⭐⭐⭐⭐

**Status:** Community-driven, muito completo  
**Viabilidade:** Alta  
**Prioridade:** 🟠 ALTA

**Dados disponíveis:**
- ✅ 38,000+ decks publicados
- ✅ Decklists completas
- ✅ Tournament results
- ✅ Meta statistics
- ✅ Card prices
- ✅ Event info

**Scraper:** ✅ Já implementado (inkdecks-scraper-v2.js)

**Estrutura:**
```
/lorcana-decks/core → Listagem
/lorcana-metagame/deck-NAME-ID → Deck individual
```

**Best practices:**
- ✅ Rate limit: 2 segundos entre requests
- ✅ User-Agent realista
- ✅ Respeitar robots.txt
- ✅ Cache local
- ✅ Incremental updates

---

### **4. DreamBorn.ink** ⭐⭐⭐⭐

**Status:** Database oficial de cartas + tournament tracker  
**Viabilidade:** Alta  
**Prioridade:** 🟡 MÉDIA-ALTA

**Dados disponíveis:**
- ✅ Card database completo
- ✅ Tournament results
- ✅ Decklists
- ✅ Meta analysis
- ✅ API disponível (cards)

**API base:** `https://api.lorcana-api.com`

**Endpoints conhecidos:**
```javascript
// Cards
GET https://api.lorcana-api.com/bulk/cards
GET https://api.lorcana-api.com/cards/{id}

// Sets
GET https://api.lorcana-api.com/sets

// Pode ter endpoints de tournaments (investigar)
GET https://api.lorcana-api.com/tournaments (?)
```

**Vantagens:**
- API pública disponível
- Documentação (parcial)
- Comunidade ativa

---

### **5. Lorcana Lair** ⭐⭐⭐

**Status:** Community hub (Discord + Website)  
**Viabilidade:** Média  
**Prioridade:** 🟡 MÉDIA

**Dados disponíveis:**
- ✅ Tournament announcements
- ✅ Results (Discord posts)
- ⚠️ Decklists (não estruturados)
- ✅ Community meta reports

**URL:** `https://lorcanalair.com` (verificar)

**Estratégia:**
- Scraping do site
- Bot de Discord (com permissão)
- RSS se disponível

---

### **6. Pixelborn Community** ⭐⭐⭐

**Status:** Simulador digital + community  
**Viabilidade:** Média (pode ser bloqueado)  
**Prioridade:** 🟡 MÉDIA

**Dados disponíveis:**
- ✅ Online tournaments
- ✅ Decklists
- ✅ Win rates
- ⚠️ Digital-only (não todos são presenciais)

**Nota:** Pixelborn é simulador não-oficial, dados podem não refletir meta presencial.

---

## 📊 FONTES ADICIONAIS (Prioridade Baixa)

### **7. Challonge.com** ⭐⭐

**Viabilidade:** Alta (API disponível)  
**Prioridade:** 🟢 BAIXA-MÉDIA

**API:** `https://api.challonge.com/v1/`

Alguns TOs usam Challonge para brackets.

---

### **8. Start.gg (Smash.gg)** ⭐⭐

**Viabilidade:** Alta (API GraphQL)  
**Prioridade:** 🟢 BAIXA

Poucos eventos Lorcana, mas alguns grandes.

---

### **9. TCGPlayer Events** ⭐⭐⭐

**Viabilidade:** Média  
**Prioridade:** 🟢 MÉDIA

TCGPlayer hospeda alguns eventos grandes.

---

## 🎯 ESTRATÉGIA RECOMENDADA

### **Fase 1: Foundation (Imediato)**
1. ✅ inkDecks scraper (já implementado)
2. ⬜ DreamBorn API integration
3. ⬜ Melee.gg bypass (User-Agent rotation)

### **Fase 2: Official Sources (1-2 meses)**
4. ⬜ Contatar Ravensburger para API
5. ⬜ Investigar play.ravensburger.com
6. ⬜ Parceria com Melee.gg (se possível)

### **Fase 3: Community (2-3 meses)**
7. ⬜ Lorcana Lair integration
8. ⬜ Discord bots (com permissão)
9. ⬜ RSS aggregation

### **Fase 4: Expansion (3+ meses)**
10. ⬜ Challonge API
11. ⬜ Start.gg GraphQL
12. ⬜ TCGPlayer events

---

## 📝 TEMPLATE DE INTEGRAÇÃO

Para cada nova fonte, criar:

```javascript
// sources/[SOURCE-NAME]-scraper.js

module.exports = {
  name: 'Source Name',
  priority: 'HIGH|MEDIUM|LOW',
  
  async fetchTournaments(options = {}) {
    // Implementação
  },
  
  async fetchDeck(deckId) {
    // Implementação
  },
  
  // Rate limiting config
  rateLimit: {
    requestsPerSecond: 0.5,
    maxRetries: 3,
  },
};
```

---

## ⚖️ CONSIDERAÇÕES LEGAIS

### **Web Scraping Guidelines:**
1. ✅ **Sempre verificar robots.txt**
2. ✅ **Respeitar rate limits**
3. ✅ **User-Agent identificável**
4. ✅ **Não sobrecarregar servidores**
5. ✅ **Cache local agressivo**
6. ✅ **Incremental updates**

### **Terms of Service:**
- ✅ Verificar ToS de cada site
- ✅ Não violar copyright
- ✅ Atribuir fontes corretamente
- ✅ Não revender dados

### **Fair Use:**
- ✅ Dados públicos = OK
- ✅ Agregação/análise = OK
- ✅ Atribuição = Necessária
- ❌ Scraping agressivo = Evitar

---

## 📞 CONTATOS PARA PARCERIAS

**Ravensburger:**
- Website: https://www.ravensburger.com
- Suporte: Formulário de contato no site
- Social: @Ravensburger (Twitter)

**Melee.gg:**
- Website: https://melee.gg
- Email: support@melee.gg (verificar)
- Discord: Link no site

**DreamBorn:**
- Website: https://dreamborn.ink
- Discord: Comunidade Lorcana

**inkDecks:**
- Website: https://inkdecks.com
- Contato: Formulário no site

---

## 🔄 ATUALIZAÇÃO E MANUTENÇÃO

**Frequência recomendada:**
- inkDecks: Diário (automático via cron)
- DreamBorn: 2x/semana
- Ravensburger: Semanal (quando disponível)
- Outros: Mensal

**Monitoramento:**
- Logs de sucesso/falha
- Decks novos vs duplicados
- Performance de cada fonte
- Rate limit violations

---

**Última atualização:** 2026-02-19  
**Versão:** 1.0  
**Autor:** Lorcana AI Team
