# 📘 GUIA DE IMPLEMENTAÇÃO - Lorcana AI v4.3 → v5.0

## 📋 VISÃO GERAL

Este guia detalha como implementar **todas as melhorias** criadas nesta sessão:

1. ✅ **inkdecks-scraper-v2.js** - Scraper robusto
2. ✅ **DeckAnalyzer-ENHANCED.jsx** - Analyzer com curva de ink
3. ✅ **mulliganAdvisor-SMART.js** - Mulligan inteligente
4. ✅ **TOURNAMENT-SOURCES.md** - Fontes de dados
5. ✅ **RAVENSBURGER-INTEGRATION.md** - Integração oficial

---

## 🎯 OBJETIVOS

### **Curto Prazo (Esta Semana)**
- [ ] Instalar inkdecks scraper v2
- [ ] Atualizar Deck Analyzer com curva de ink
- [ ] Atualizar Mulligan Advisor com lógica smart

### **Médio Prazo (Este Mês)**
- [ ] Adicionar mais fontes de dados
- [ ] Investigar API Ravensburger
- [ ] Melhorar performance do scraper

### **Longo Prazo (3-6 Meses)**
- [ ] Integração completa com Ravensburger
- [ ] Sistema de TO (Tournament Organizer)
- [ ] Mobile app

---

## 📦 PARTE 1: INKDECKS SCRAPER V2

### **1.1 Instalação**

```powershell
cd S:\INKREC\lorcana_ai\backend

# Copiar arquivo
copy ..\inkdecks-scraper-v2.js services\scrapers\inkdecks-scraper-v2.js

# Instalar dependências (se necessário)
npm install axios cheerio
```

---

### **1.2 Configuração**

Editar configurações no arquivo se necessário:

```javascript
const CONFIG = {
  baseUrl: 'https://inkdecks.com',
  listingUrl: '/lorcana-decks/core',
  
  // Ajustar conforme necessário
  requestDelay: 2000,       // 2s entre requests
  maxRetries: 3,
  maxDecksPerRun: 100,      // Limitar para não sobrecarregar
  
  // Paths
  outputDir: path.join(__dirname, '../db'),
  outputFile: 'tournamentMeta.json',
};
```

---

### **1.3 Primeiro Run Manual**

```powershell
cd backend\services\scrapers

# Testar com poucos decks primeiro
node inkdecks-scraper-v2.js --max 10

# Ver resultados
type ..\..\db\tournamentMeta.json

# Se funcionou, rodar completo
node inkdecks-scraper-v2.js --max 100
```

**Output esperado:**
```
[2026-02-19] [INFO] Scraping deck listing...
[2026-02-19] [SUCCESS] Found 10 decks in listing
[2026-02-19] [INFO] Scraping 10 deck details...
[2026-02-19] [SUCCESS] Scraped deck: PS tempo (52 cards)
...
[2026-02-19] [SUCCESS] Saved 10 decks to tournamentMeta.json
```

---

### **1.4 Automatizar com Cron (Agendamento)**

**Windows (Task Scheduler):**

1. Criar arquivo `run-scraper.bat`:
```batch
@echo off
cd S:\INKREC\lorcana_ai\backend\services\scrapers
node inkdecks-scraper-v2.js --max 50
```

2. Agendar:
   - Abrir **Task Scheduler**
   - Create Basic Task
   - Name: "Lorcana Scraper Daily"
   - Trigger: Daily, 3:00 AM
   - Action: Start Program
   - Program: `S:\INKREC\lorcana_ai\backend\run-scraper.bat`

**Linux/Mac (crontab):**
```bash
# Editar crontab
crontab -e

# Adicionar linha (rodar todo dia 3am)
0 3 * * * cd /path/to/backend && node services/scrapers/inkdecks-scraper-v2.js --max 50
```

---

### **1.5 Monitoramento**

```powershell
# Ver logs
type backend\db\scraper.log

# Ver últimos 20 decks
node -e "console.log(require('./backend/db/tournamentMeta.json').slice(0,20))"
```

---

## 📊 PARTE 2: DECK ANALYZER ENHANCED

### **2.1 Backup do Atual**

```powershell
cd S:\INKREC\lorcana_ai\frontend\src

# Backup
copy DeckAnalyzer.jsx DeckAnalyzer.jsx.bak
```

---

### **2.2 Instalar Nova Versão**

```powershell
# Copiar enhanced version
copy ..\..\DeckAnalyzer-ENHANCED.jsx DeckAnalyzer.jsx
```

---

### **2.3 Adicionar Estilos CSS**

Adicionar ao `DeckAnalyzer.css`:

```css
/* ── Ink Curve Chart ────────────────────────────────────────────────── */

.ink-curve-chart {
  padding: 20px;
}

.ink-curve-bars {
  display: flex;
  align-items: flex-end;
  gap: 8px;
  height: 150px;
  padding: 10px 0;
}

.ink-curve-bar-wrap {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
}

.ink-curve-bar {
  width: 100%;
  background: linear-gradient(180deg, 
    var(--accent, #7c3aed) 0%, 
    var(--accent2, #8b5cf6) 100%
  );
  border-radius: 4px 4px 0 0;
  position: relative;
  transition: all 0.3s;
  min-height: 4px;
}

.ink-curve-bar:hover {
  background: var(--accent2, #8b5cf6);
  transform: translateY(-2px);
}

.ink-curve-bar-value {
  position: absolute;
  top: -20px;
  left: 50%;
  transform: translateX(-50%);
  font-size: 12px;
  font-weight: 600;
  color: var(--text, #ffffff);
}

.ink-curve-label {
  font-size: 11px;
  color: var(--text2, rgba(255, 255, 255, 0.6));
  font-weight: 600;
}

/* ── Type Distribution ──────────────────────────────────────────────── */

.type-distribution {
  display: flex;
  flex-direction: column;
  gap: 12px;
  padding: 10px 0;
}

.type-bar-row {
  display: flex;
  align-items: center;
  gap: 12px;
}

.type-label {
  width: 120px;
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  font-weight: 600;
  color: var(--text, #ffffff);
  text-transform: capitalize;
}

.type-icon {
  width: 20px;
  height: 20px;
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
}

.type-icon-character { background: #10b981; }
.type-icon-action { background: #ef4444; }
.type-icon-item { background: #f59e0b; }
.type-icon-song { background: #8b5cf6; }
.type-icon-location { background: #06b6d4; }

.type-bar-wrap {
  flex: 1;
  position: relative;
  height: 24px;
  background: var(--bg2, rgba(255, 255, 255, 0.05));
  border-radius: 4px;
  overflow: hidden;
}

.type-bar {
  height: 100%;
  display: flex;
  align-items: center;
  padding-left: 8px;
  transition: width 0.5s;
  border-radius: 4px;
}

.type-bar-character { background: #10b981; }
.type-bar-action { background: #ef4444; }
.type-bar-item { background: #f59e0b; }
.type-bar-song { background: #8b5cf6; }
.type-bar-location { background: #06b6d4; }

.type-bar-value {
  font-size: 12px;
  font-weight: 700;
  color: white;
}

.type-pct {
  width: 50px;
  text-align: right;
  font-size: 13px;
  font-weight: 600;
  color: var(--text2, rgba(255, 255, 255, 0.7));
}

/* ── Advanced Stats Grid ────────────────────────────────────────────── */

.advanced-stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  gap: 16px;
}

.stat-card {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 16px;
  background: var(--bg2, rgba(255, 255, 255, 0.05));
  border: 1px solid var(--border, rgba(255, 255, 255, 0.1));
  border-radius: 8px;
  transition: all 0.2s;
}

.stat-card:hover {
  border-color: var(--accent, #7c3aed);
  transform: translateY(-2px);
}

.stat-icon {
  font-size: 28px;
}

.stat-content {
  flex: 1;
}

.stat-value {
  font-size: 24px;
  font-weight: 700;
  color: var(--text, #ffffff);
  line-height: 1;
  margin-bottom: 4px;
}

.stat-label {
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: var(--text3, rgba(255, 255, 255, 0.5));
  font-weight: 600;
}

.stat-sub {
  font-size: 10px;
  color: var(--text3, rgba(255, 255, 255, 0.4));
  margin-top: 2px;
}

/* ── Meta Performance ───────────────────────────────────────────────── */

.meta-performance-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
  gap: 16px;
}

.meta-perf-item {
  text-align: center;
  padding: 12px;
  background: var(--bg, rgba(0, 0, 0, 0.2));
  border-radius: 8px;
}

.meta-perf-label {
  font-size: 11px;
  text-transform: uppercase;
  color: var(--text3, rgba(255, 255, 255, 0.5));
  margin-bottom: 8px;
}

.meta-perf-value {
  font-size: 24px;
  font-weight: 700;
  color: var(--accent, #7c3aed);
}

/* ── Adds/Cuts ──────────────────────────────────────────────────────── */

.adds-cuts-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 24px;
}

@media (max-width: 768px) {
  .adds-cuts-grid {
    grid-template-columns: 1fr;
  }
}

.ac-list {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.ac-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px;
  background: var(--bg2, rgba(255, 255, 255, 0.05));
  border-radius: 8px;
  border: 1px solid transparent;
  transition: all 0.2s;
}

.ac-item.add {
  border-left: 3px solid #10b981;
}

.ac-item.cut {
  border-left: 3px solid #ef4444;
}

.ac-item:hover {
  border-color: var(--accent, #7c3aed);
}

.ac-name {
  font-size: 14px;
  font-weight: 600;
  color: var(--text, #ffffff);
}

.ac-meta {
  display: flex;
  align-items: center;
  gap: 8px;
}

.qty-chip {
  padding: 2px 8px;
  background: var(--bg, rgba(0, 0, 0, 0.3));
  border-radius: 4px;
  font-size: 12px;
  font-weight: 700;
  color: var(--text, #ffffff);
}
```

---

### **2.4 Testar**

```powershell
cd frontend
npm start

# Abrir http://localhost:3001
# Ir para Deck Analyzer
# Colar deck e analisar
# Deve mostrar curva de ink, type distribution, etc.
```

---

## 🧠 PARTE 3: MULLIGAN ADVISOR SMART

### **3.1 Backup**

```powershell
cd S:\INKREC\lorcana_ai\backend\services\ai

# Se existir mulliganAdvisor.js
copy mulliganAdvisor.js mulliganAdvisor.js.bak
```

---

### **3.2 Instalar**

```powershell
# Copiar smart version
copy ..\..\..\mulliganAdvisor-SMART.js mulliganAdvisor.js
```

---

### **3.3 Verificar Backend**

O `routes/ai.js` já deve estar chamando:
```javascript
const { analyzeMulligan } = require('../services/ai/mulliganAdvisor');
```

Apenas certifique-se que está usando a versão correta (routes-ai-WORKING.js).

---

### **3.4 Testar**

```powershell
cd backend
npm start

# Frontend: http://localhost:3001
# Hand Analyzer → Embaralhar → Analisar Mão
# Deve mostrar:
# - Estratégia detectada (Aggro/Midrange/Control)
# - Análise detalhada
# - Sugestões de mulligan com motivos
```

---

## 📈 PARTE 4: ADICIONAR MAIS FONTES

### **4.1 DreamBorn API**

```javascript
// services/scrapers/dreamborn-scraper.js

const axios = require('axios');

async function fetchCardsFromDreamBorn() {
  const response = await axios.get('https://api.lorcana-api.com/bulk/cards');
  return response.data;
}

async function fetchSetsFromDreamBorn() {
  const response = await axios.get('https://api.lorcana-api.com/sets');
  return response.data;
}

module.exports = { fetchCardsFromDreamBorn, fetchSetsFromDreamBorn };
```

Agendar update semanal de cards.

---

### **4.2 Melee.gg (Bypass User-Agent)**

```javascript
// services/scrapers/melee-scraper.js

const axios = require('axios');
const cheerio = require('cheerio');

const USER_AGENTS = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36...',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)...',
  'Mozilla/5.0 (X11; Linux x86_64)...',
];

function getRandomUserAgent() {
  return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
}

async function fetchMeleeEvents() {
  const response = await axios.get('https://melee.gg/Tournament/View/XXXXX', {
    headers: {
      'User-Agent': getRandomUserAgent(),
    },
  });
  
  const $ = cheerio.load(response.data);
  // Parse standings
}

module.exports = { fetchMeleeEvents };
```

---

## 🎮 PARTE 5: RAVENSBURGER INTEGRATION (Futuro)

### **5.1 Investigação Inicial**

1. **Verificar documentação:**
   - https://play.ravensburger.com/api
   - https://developers.ravensburger.com

2. **DevTools analysis:**
   - Abrir play.ravensburger.com
   - F12 → Network
   - Ver requests

3. **Contatar Ravensburger:**
   - Usar template de email no RAVENSBURGER-INTEGRATION.md

---

### **5.2 Implementação (Quando API disponível)**

```javascript
// services/ravensburger/api.js

class RavensburgerAPI {
  constructor(apiKey) {
    this.baseUrl = 'https://api.ravensburger.com';
    this.apiKey = apiKey;
  }
  
  async getTournaments(filters = {}) {
    // Implementar baseado em docs
  }
}

module.exports = RavensburgerAPI;
```

---

## ✅ CHECKLIST DE VALIDAÇÃO

Após implementar tudo:

### **Backend:**
- [ ] Scraper roda sem erros
- [ ] tournamentMeta.json atualizado
- [ ] Logs de scraper limpos
- [ ] Mulligan advisor retorna decisões inteligentes
- [ ] API /api/ai/mulligan funciona

### **Frontend:**
- [ ] Deck Analyzer mostra curva de ink
- [ ] Type distribution funciona
- [ ] Stats avançadas aparecem
- [ ] Meta comparison funciona
- [ ] Hand Analyzer mostra decisão de mulligan
- [ ] Sugestões de mulligan aparecem

### **Performance:**
- [ ] Scraper não sobrecarrega inkdecks
- [ ] Frontend carrega rápido
- [ ] Backend responde < 1s

---

## 🐛 TROUBLESHOOTING

### **Problema: Scraper falha com 403**
**Solução:** 
- Aumentar `requestDelay` para 3-5s
- Verificar User-Agent
- Verificar robots.txt

### **Problema: Curva de ink não aparece**
**Solução:**
- Verificar se cards têm campo `cost`
- Ver console do browser (F12)
- Verificar CSS foi copiado

### **Problema: Mulligan sempre "Keep"**
**Solução:**
- Verificar se deck tem campo `cards` preenchido
- Ver logs do backend
- Testar com deck conhecido

---

## 📊 MÉTRICAS DE SUCESSO

Após 1 semana:
- ✅ Scraper rodou pelo menos 5x
- ✅ 100+ decks novos no DB
- ✅ Usuários testaram Deck Analyzer enhanced
- ✅ Mulligan advisor usado 20+ vezes

Após 1 mês:
- ✅ 500+ decks no DB
- ✅ 3+ fontes de dados ativas
- ✅ Ravensburger investigado
- ✅ Performance otimizada

---

## 🚀 PRÓXIMOS PASSOS

1. **Esta semana:**
   - Implementar tudo deste guia
   - Testar exaustivamente
   - Coletar feedback

2. **Próximas 2 semanas:**
   - Adicionar mais fontes
   - Otimizar performance
   - Melhorar UI/UX

3. **Próximo mês:**
   - Ravensburger integration
   - Mobile app (React Native?)
   - Sistema de TO

---

**Última atualização:** 2026-02-19  
**Versão:** 1.0  
**Autor:** Lorcana AI Team
