# 🎮 INTEGRAÇÃO COM PLAY.RAVENSBURGER.COM

## 📋 VISÃO GERAL

Plano completo para integração com a plataforma oficial **play.ravensburger.com** para:
1. **Ler resultados** de torneios oficiais
2. **Reportar resultados** (Tournament Organizers)
3. **Sync bidirecional** (futuro)

---

## 🎯 OBJETIVOS

### **Curto Prazo (1-3 meses)**
- [ ] Investigar API disponível
- [ ] Scraping de resultados públicos (se API não disponível)
- [ ] Importar resultados oficiais automaticamente

### **Médio Prazo (3-6 meses)**
- [ ] Sistema de reporting para TOs
- [ ] Integração com sistema local de pairings
- [ ] Export de resultados para Ravensburger

### **Longo Prazo (6-12 meses)**
- [ ] Sync bidirecional completo
- [ ] App oficial de TO parceiro
- [ ] DCI-like system para Lorcana

---

## 🔍 FASE 1: INVESTIGAÇÃO

### **1.1 Verificar Documentação Pública**

**URLs para verificar:**
```
https://play.ravensburger.com/api
https://play.ravensburger.com/docs
https://play.ravensburger.com/api/v1
https://developers.ravensburger.com
https://api.ravensburger.com
```

**O que procurar:**
- ✅ Endpoints públicos
- ✅ Documentação de API
- ✅ OAuth/API keys
- ✅ Rate limits
- ✅ Terms of Service

---

### **1.2 Análise de Requisições (DevTools)**

**Processo:**

1. **Abrir DevTools** no navegador
2. **Ir para Network tab**
3. **Navegar no site** play.ravensburger.com
4. **Observar requests:**

```javascript
// Exemplo de requests que podem existir:
GET /api/tournaments?game=lorcana&status=completed
GET /api/tournaments/{id}/standings
GET /api/tournaments/{id}/decks
GET /api/events/upcoming
```

**Informações a capturar:**
- Base URL da API
- Headers necessários (Authorization, API-Key, etc)
- Formato de resposta (JSON, XML)
- Paginação
- Filtros disponíveis

---

### **1.3 Verificar Robots.txt**

```bash
curl https://play.ravensburger.com/robots.txt
```

**Verificar:**
- Caminhos permitidos para scraping
- Caminhos bloqueados
- Crawl-delay recomendado
- Sitemaps disponíveis

---

### **1.4 Análise de HTML (se scraping necessário)**

**Estrutura típica esperada:**

```html
<!-- Listagem de torneios -->
<div class="tournament-list">
  <div class="tournament-item" data-id="12345">
    <h3>Event Name</h3>
    <span class="date">2026-02-15</span>
    <span class="location">São Paulo, BR</span>
    <span class="players">64 players</span>
  </div>
</div>

<!-- Standings -->
<table class="standings">
  <tr data-player-id="67890">
    <td class="rank">1</td>
    <td class="player">Player Name</td>
    <td class="points">18</td>
    <td class="decklist-link"><a href="/deck/12345">View</a></td>
  </tr>
</table>
```

---

## 🔌 FASE 2: IMPLEMENTAÇÃO (READ-ONLY)

### **2.1 API Integration (se disponível)**

**Exemplo de implementação:**

```javascript
// services/ravensburger/api.js

const axios = require('axios');

class RavensburgerAPI {
  constructor(apiKey) {
    this.baseUrl = 'https://api.ravensburger.com';
    this.apiKey = apiKey;
  }
  
  async getTournaments(filters = {}) {
    const params = {
      game: 'lorcana',
      status: filters.status || 'completed',
      format: filters.format || 'core',
      limit: filters.limit || 100,
      offset: filters.offset || 0,
    };
    
    const response = await axios.get(`${this.baseUrl}/tournaments`, {
      params,
      headers: {
        'Authorization': `Bearer ${this.apiKey}`,
        'Accept': 'application/json',
      },
    });
    
    return response.data;
  }
  
  async getTournamentDetails(tournamentId) {
    const response = await axios.get(
      `${this.baseUrl}/tournaments/${tournamentId}`,
      {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Accept': 'application/json',
        },
      }
    );
    
    return response.data;
  }
  
  async getStandings(tournamentId) {
    const response = await axios.get(
      `${this.baseUrl}/tournaments/${tournamentId}/standings`,
      {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Accept': 'application/json',
        },
      }
    );
    
    return response.data;
  }
  
  async getDecklist(decklistId) {
    const response = await axios.get(
      `${this.baseUrl}/decklists/${decklistId}`,
      {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Accept': 'application/json',
        },
      }
    );
    
    return response.data;
  }
}

module.exports = RavensburgerAPI;
```

**Usage:**

```javascript
const RavensburgerAPI = require('./services/ravensburger/api');

const api = new RavensburgerAPI(process.env.RAVENSBURGER_API_KEY);

// Buscar torneios recentes
const tournaments = await api.getTournaments({
  status: 'completed',
  format: 'core',
  limit: 50,
});

// Buscar detalhes de um torneio
const details = await api.getTournamentDetails(tournaments[0].id);

// Buscar standings
const standings = await api.getStandings(tournaments[0].id);
```

---

### **2.2 Scraper Implementation (fallback)**

**Se API não disponível:**

```javascript
// services/ravensburger/scraper.js

const axios = require('axios');
const cheerio = require('cheerio');

class RavensburgerScraper {
  constructor() {
    this.baseUrl = 'https://play.ravensburger.com';
  }
  
  async getTournaments(options = {}) {
    const url = `${this.baseUrl}/lorcana/tournaments`;
    
    const html = await axios.get(url, {
      headers: {
        'User-Agent': 'LorcanaAI/1.0 (Tournament Aggregator)',
      },
    });
    
    const $ = cheerio.load(html.data);
    const tournaments = [];
    
    // Adaptar seletores baseado na estrutura real
    $('.tournament-item').each((_, el) => {
      tournaments.push({
        id: $(el).attr('data-id'),
        name: $(el).find('.tournament-name').text(),
        date: $(el).find('.tournament-date').text(),
        location: $(el).find('.tournament-location').text(),
        players: parseInt($(el).find('.player-count').text()),
        url: $(el).find('a').attr('href'),
      });
    });
    
    return tournaments;
  }
  
  async getStandings(tournamentId) {
    const url = `${this.baseUrl}/lorcana/tournaments/${tournamentId}/standings`;
    // Similar implementation
  }
}

module.exports = RavensburgerScraper;
```

---

### **2.3 Data Normalization**

**Converter dados de Ravensburger para formato interno:**

```javascript
// services/ravensburger/normalizer.js

function normalizeTournament(rawData, source = 'api') {
  return {
    source: 'ravensburger',
    sourceType: source, // 'api' ou 'scraper'
    tournamentId: rawData.id || rawData.tournamentId,
    name: rawData.name || rawData.eventName,
    date: rawData.date || rawData.startDate,
    location: {
      city: rawData.city,
      state: rawData.state,
      country: rawData.country,
    },
    format: rawData.format || 'core',
    players: rawData.playerCount || rawData.players,
    rounds: rawData.rounds,
    topCut: rawData.topCut || 8,
    standings: rawData.standings?.map(normalizeStanding) || [],
    fetchedAt: new Date().toISOString(),
  };
}

function normalizeStanding(rawStanding) {
  return {
    rank: rawStanding.rank || rawStanding.position,
    playerName: rawStanding.name || rawStanding.playerName,
    playerId: rawStanding.playerId,
    points: rawStanding.points,
    matchWins: rawStanding.wins,
    matchLosses: rawStanding.losses,
    matchDraws: rawStanding.draws,
    decklistUrl: rawStanding.decklistUrl,
  };
}

module.exports = { normalizeTournament, normalizeStanding };
```

---

## 📤 FASE 3: TOURNAMENT REPORTING (WRITE)

### **3.1 Sistema de TO (Tournament Organizer)**

**Para TOs reportarem resultados:**

```javascript
// Frontend: TO Dashboard

// 1. TO cria evento local no Lorcana AI
const event = await createEvent({
  name: 'Local Championship',
  date: '2026-03-15',
  format: 'core',
  expectedPlayers: 32,
});

// 2. TO roda torneio (swiss + top 8)
// Sistema gera pairings, tracking de resultados, etc.

// 3. Ao final, TO pode exportar para Ravensburger
await exportToRavensburger(event.id, {
  apiKey: TO_API_KEY,
  sanctioned: true, // Se evento é sancionado
});
```

**Backend implementation:**

```javascript
// routes/tournament-organizer.js

router.post('/events/:eventId/export/ravensburger', async (req, res) => {
  const { eventId } = req.params;
  const { apiKey, sanctioned } = req.body;
  
  // 1. Carregar evento local
  const event = await getEvent(eventId);
  
  // 2. Converter para formato Ravensburger
  const ravensburgerFormat = {
    event_name: event.name,
    date: event.date,
    format: event.format,
    sanctioned: sanctioned,
    standings: event.standings.map(s => ({
      player_name: s.playerName,
      player_id: s.playerId, // Se player tem conta Ravensburger
      rank: s.rank,
      points: s.points,
      wins: s.wins,
      losses: s.losses,
      draws: s.draws,
      decklist: s.decklist,
    })),
  };
  
  // 3. Enviar para Ravensburger
  const api = new RavensburgerAPI(apiKey);
  const result = await api.submitTournamentResults(ravensburgerFormat);
  
  res.json({
    success: true,
    ravensburgerId: result.tournament_id,
    url: result.url,
  });
});
```

---

### **3.2 Formato de Export**

**JSON esperado por Ravensburger (exemplo hipotético):**

```json
{
  "event": {
    "name": "Local Championship",
    "date": "2026-03-15",
    "format": "core",
    "sanctioned": true,
    "organizer": {
      "id": "TO_12345",
      "name": "Store Name"
    },
    "location": {
      "city": "São Paulo",
      "state": "SP",
      "country": "BR"
    }
  },
  "standings": [
    {
      "rank": 1,
      "player": {
        "id": "PLAYER_67890",
        "name": "John Doe"
      },
      "record": {
        "wins": 6,
        "losses": 0,
        "draws": 1
      },
      "decklist": {
        "name": "Blurple Control",
        "cards": [
          { "card_id": "TFC-001", "quantity": 4 },
          { "card_id": "TFC-002", "quantity": 3 }
        ]
      }
    }
  ]
}
```

---

## 🔄 FASE 4: SYNC BIDIRECIONAL

### **4.1 Webhook Integration**

**Se Ravensburger suportar webhooks:**

```javascript
// routes/webhooks/ravensburger.js

router.post('/webhooks/ravensburger/tournament-completed', async (req, res) => {
  const { tournament_id, status } = req.body;
  
  // Verificar autenticidade (HMAC signature)
  if (!verifyWebhookSignature(req)) {
    return res.status(401).json({ error: 'Invalid signature' });
  }
  
  // Buscar dados do torneio
  const api = new RavensburgerAPI(process.env.RAVENSBURGER_API_KEY);
  const tournament = await api.getTournamentDetails(tournament_id);
  
  // Importar para DB local
  await importTournament(tournament);
  
  res.json({ success: true });
});
```

---

### **4.2 Scheduled Sync**

**Cron job para sync periódico:**

```javascript
// scripts/sync-ravensburger.js

const cron = require('node-cron');
const RavensburgerAPI = require('../services/ravensburger/api');

// Rodar todo dia às 3am
cron.schedule('0 3 * * *', async () => {
  console.log('Starting Ravensburger sync...');
  
  const api = new RavensburgerAPI(process.env.RAVENSBURGER_API_KEY);
  
  // Buscar novos torneios dos últimos 7 dias
  const tournaments = await api.getTournaments({
    since: Date.now() - 7 * 24 * 60 * 60 * 1000,
  });
  
  let imported = 0;
  for (const tournament of tournaments) {
    const exists = await tournamentExists(tournament.id);
    if (!exists) {
      await importTournament(tournament);
      imported++;
    }
  }
  
  console.log(`Sync complete. Imported ${imported} new tournaments.`);
});
```

---

## 📝 CONTATO COM RAVENSBURGER

### **Email Template:**

```
Subject: API Access Request for Lorcana Tournament Management Tool

Dear Ravensburger Developer Relations Team,

I am developing a tournament management and meta analysis tool for Disney Lorcana TCG 
called "Lorcana AI". The tool helps Tournament Organizers run events and provides 
meta analysis for players.

We would like to integrate with play.ravensburger.com to:
1. Import official tournament results into our meta database
2. Allow TOs to report tournament results to your platform
3. Provide players with comprehensive meta insights

Could you please provide:
- Access to your public API (if available)
- API documentation
- Developer account/API key
- Terms of Service for API usage

Our tool respects rate limits and follows best practices for API integration.

Website: [your-website]
GitHub: [if open source]

Thank you for your consideration.

Best regards,
[Your Name]
[Contact Info]
```

---

## ⚖️ CONSIDERAÇÕES LEGAIS

### **Terms of Service:**
- ✅ Ler e respeitar ToS de Ravensburger
- ✅ Não violar propriedade intelectual
- ✅ Atribuir fonte corretamente
- ✅ Não revender dados

### **Data Privacy:**
- ✅ Não armazenar dados pessoais sem consentimento
- ✅ GDPR compliance (se aplicável)
- ✅ Anonimizar dados quando possível

### **API Usage:**
- ✅ Respeitar rate limits
- ✅ Não sobrecarregar sistemas
- ✅ Cache agressivo
- ✅ Graceful degradation

---

## 📊 MÉTRICAS DE SUCESSO

**KPIs para medir sucesso da integração:**

- **Coverage:** % de torneios oficiais capturados
- **Latency:** Tempo entre torneio terminar e aparecer no sistema
- **Accuracy:** % de dados corretos vs incorretos
- **Uptime:** % de tempo que integração funciona
- **TO Adoption:** % de TOs usando sistema de reporting

---

## 🗓️ TIMELINE PROPOSTO

### **Mês 1: Investigação**
- Pesquisar API/scraping
- Contatar Ravensburger
- Protótipo básico

### **Mês 2-3: Implementação Read**
- API integration ou scraper
- Normalização de dados
- Testes

### **Mês 4-5: Implementação Write**
- Sistema de reporting para TOs
- Export para Ravensburger
- Beta testing com TOs locais

### **Mês 6+: Refinamento**
- Webhooks
- Sync automático
- Scale testing

---

**Status:** 📋 Planning  
**Última atualização:** 2026-02-19  
**Versão:** 1.0
