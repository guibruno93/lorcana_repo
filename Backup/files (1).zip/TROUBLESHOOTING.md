# 🔧 TROUBLESHOOTING - Guia Rápido

## ❌ Erro: "Cannot destructure property 'decklist' of 'req.body' as it is undefined"

### Causa:
A rota `/api/deck` não está registrada no `server.js`

### Solução:
1. **Copie o novo `server.js`** para `backend/server.js`
2. Reinicie o backend

**OU** adicione manualmente ao `server.js` existente:

```javascript
// Depois do app.use(express.json())
// e ANTES do app.use("/api/ai", aiRouter)

// Adicionar esta seção:
try {
  const deckRouter = require("./routes/deck");
  app.use("/api/deck", deckRouter);
  console.log("✅ Deck router carregado: /api/deck");
} catch (e) {
  console.warn("⚠️ Deck router não carregado:", e.message);
}
```

---

## ❌ Erro: "Cannot find module './routes/deck'"

### Causa:
O arquivo `routes/deck.js` não existe ou está no lugar errado

### Solução:
Certifique-se que copiou:
```
routes-deck.js → backend/routes/deck.js
```

**Verificar:**
```powershell
cd backend
dir routes\deck.js
# Deve existir
```

---

## ❌ Erro: "Cannot find module '../parser/metaComparator'"

### Causa:
O `metaComparator-v2.js` não foi copiado

### Solução:
```powershell
cd backend
copy metaComparator-v2.js parser\metaComparator.js
```

---

## ❌ Erro no frontend: "Failed to fetch" ou "Network Error"

### Causa:
Backend não está rodando ou porta errada

### Solução:
1. Verificar se backend está rodando:
   ```powershell
   curl http://localhost:5000/api/health
   # Deve retornar: {"ok":true}
   ```

2. Se não funcionar, reiniciar backend:
   ```powershell
   cd backend
   npm start
   ```

3. Verificar se a porta está correta no frontend (`App.jsx` linha 4):
   ```javascript
   const API = "http://localhost:5000";
   ```

---

## ❌ Erro: "EADDRINUSE: address already in use :::5000"

### Causa:
Já existe um processo rodando na porta 5000

### Solução Windows:
```powershell
# Encontrar processo
netstat -ano | findstr :5000

# Matar processo (substitua PID pelo número encontrado)
taskkill /PID <PID> /F
```

---

## ❌ Frontend não atualiza / mudanças não aparecem

### Causa:
Cache do React / browser

### Solução:
1. Parar o frontend (Ctrl+C)
2. Limpar cache:
   ```powershell
   cd frontend
   rmdir /S /Q node_modules\.cache
   ```
3. Reiniciar:
   ```powershell
   npm start
   ```

4. No browser: Ctrl+Shift+R (hard refresh)

---

## ❌ Adds/Cuts aparecem vazios

### Causa:
`tournamentMeta.json` não foi encontrado ou está vazio

### Verificar:
```powershell
cd backend
dir db\tournamentMeta.json
# Deve existir e ter ~354KB
```

### Solução:
Se não existir, copie o arquivo original:
```powershell
copy ..\tournamentMeta.json db\tournamentMeta.json
```

---

## ❌ Matchups mostram todos 50%

### Causa:
`matchupAnalyzer-v2.js` não foi copiado corretamente

### Verificar:
```powershell
cd backend\services\ai
dir matchupAnalyzer.js
# Deve ser a versão nova (>10KB)
```

### Solução:
```powershell
cd backend
copy matchupAnalyzer-v2.js services\ai\matchupAnalyzer.js
```

---

## ✅ Checklist de instalação completa

Execute esta sequência para garantir que tudo está no lugar:

```powershell
# 1. Backend
cd S:\INKREC\lorcana_ai\backend

# Verificar arquivos críticos
dir server.js
dir routes\deck.js
dir routes\ai.js
dir parser\metaComparator.js
dir services\ai\matchupAnalyzer.js
dir db\tournamentMeta.json

# 2. Frontend
cd ..\frontend

# Verificar arquivos críticos
dir src\App.jsx
dir src\styles.css

# 3. Testar backend
cd ..\backend
npm start
# Deve mostrar: ✅ Deck router carregado: /api/deck
# Deve mostrar: ✅ AI router carregado: /api/ai

# 4. Em outro terminal, testar endpoint
curl http://localhost:5000/api/health
# Esperado: {"ok":true}

# 5. Testar frontend
cd ..\frontend
npm start
# Abrir http://localhost:3001
```

---

## 🧪 Script de teste rápido

Salve como `test-api.js` no backend:

```javascript
const http = require('http');

function test(path, body) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    const req = http.request({
      hostname: 'localhost',
      port: 5000,
      path,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': data.length,
      },
    }, (res) => {
      let d = '';
      res.on('data', chunk => d += chunk);
      res.on('end', () => {
        console.log(`${path}: ${res.statusCode}`);
        if (res.statusCode === 200) console.log('  ✅ OK');
        else console.log('  ❌ FAIL:', d.slice(0, 100));
        resolve();
      });
    });
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

(async () => {
  const decklist = '4 Tipo - Growing Son\n4 Hades - Infernal Schemer';
  
  console.log('\n🧪 Testing API endpoints...\n');
  
  await test('/api/deck/analyze', { decklist, compare: true, top: 32 });
  await test('/api/ai/matchups', { decklist });
  await test('/api/ai/shuffle', { decklist });
  
  console.log('\n✅ Tests complete\n');
})();
```

Execute:
```powershell
node test-api.js
```

---

## 📞 Ainda com problemas?

1. **Verificar logs do backend** - procure por linhas com ❌ ou ⚠️
2. **Verificar console do browser** (F12 → Console)
3. **Copiar erro completo** e verificar qual arquivo está faltando
4. **Reiniciar tudo** - Ctrl+C em ambos os terminais, depois `npm start` de novo

---

## 💡 Dica: Instalação limpa

Se nada funcionar, faça instalação limpa:

```powershell
# Backup
cd S:\INKREC
xcopy lorcana_ai lorcana_ai_backup /E /I

# Limpar
cd lorcana_ai\backend
rmdir /S /Q node_modules
del package-lock.json

cd ..\frontend
rmdir /S /Q node_modules
del package-lock.json

# Reinstalar
cd ..\backend
npm install
cd ..\frontend
npm install

# Copiar arquivos novamente (consulte INSTALL.md)
# ...

# Testar
cd ..\backend
npm start
```
