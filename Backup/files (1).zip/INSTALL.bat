@echo off
REM ═══════════════════════════════════════════════════════════════════════════
REM  LORCANA AI - Instalação Automática v3.0
REM  Visual Premium + Adds/Cuts + Matchups Precisos
REM ═══════════════════════════════════════════════════════════════════════════

echo.
echo ========================================
echo   LORCANA AI - INSTALACAO AUTOMATICA
echo   v3.0 - Premium Edition
echo ========================================
echo.

REM ── Verificar diretório ──
if not exist "backend" (
    echo ERRO: Execute este script na pasta raiz do projeto lorcana_ai
    echo Exemplo: S:\INKREC\lorcana_ai\INSTALL.bat
    echo.
    pause
    exit /b 1
)

if not exist "frontend" (
    echo ERRO: Pasta frontend nao encontrada
    pause
    exit /b 1
)

echo [1/5] Verificando arquivos baixados...
echo.

REM Lista de arquivos necessários
set "files_needed=server.js App.jsx styles.css metaComparator-v2.js matchupAnalyzer-v2.js routes-deck.js routes-ai-updated.js"

for %%f in (%files_needed%) do (
    if not exist "%%f" (
        echo   FALTA: %%f
        set missing=1
    ) else (
        echo   OK: %%f
    )
)

if defined missing (
    echo.
    echo ERRO: Alguns arquivos estao faltando.
    echo Certifique-se de baixar todos os 7 arquivos e colocar na pasta raiz.
    pause
    exit /b 1
)

echo.
echo [2/5] Parando servicos...
echo.

REM Tentar matar processos Node
taskkill /F /IM node.exe 2>nul >nul
timeout /t 2 /nobreak >nul

echo [3/5] Instalando arquivos Backend...
echo.

REM Backend
copy /Y server.js backend\server.js >nul
if errorlevel 1 goto :error_backend

copy /Y metaComparator-v2.js backend\parser\metaComparator.js >nul
if errorlevel 1 goto :error_backend

copy /Y matchupAnalyzer-v2.js backend\services\ai\matchupAnalyzer.js >nul
if errorlevel 1 goto :error_backend

copy /Y routes-deck.js backend\routes\deck.js >nul
if errorlevel 1 goto :error_backend

copy /Y routes-ai-updated.js backend\routes\ai.js >nul
if errorlevel 1 goto :error_backend

echo   [OK] server.js
echo   [OK] parser\metaComparator.js
echo   [OK] services\ai\matchupAnalyzer.js
echo   [OK] routes\deck.js
echo   [OK] routes\ai.js
echo.

echo [4/5] Instalando arquivos Frontend...
echo.

REM Frontend
copy /Y App.jsx frontend\src\App.jsx >nul
if errorlevel 1 goto :error_frontend

copy /Y styles.css frontend\src\styles.css >nul
if errorlevel 1 goto :error_frontend

echo   [OK] src\App.jsx
echo   [OK] src\styles.css
echo.

echo [5/5] Verificando dependencias...
echo.

REM Verificar tournamentMeta.json
if not exist "backend\db\tournamentMeta.json" (
    if exist "tournamentMeta.json" (
        echo   Copiando tournamentMeta.json para backend\db\
        copy tournamentMeta.json backend\db\tournamentMeta.json >nul
    ) else (
        echo   AVISO: tournamentMeta.json nao encontrado
        echo   Adds/Cuts podem nao funcionar sem este arquivo
    )
)

echo.
echo ========================================
echo   INSTALACAO CONCLUIDA COM SUCESSO!
echo ========================================
echo.
echo Proximos passos:
echo.
echo   1. cd backend
echo   2. npm start
echo.
echo   Em outro terminal:
echo   3. cd frontend
echo   4. npm start
echo.
echo   5. Abrir http://localhost:3001
echo.
echo Features instaladas:
echo   - Visual Premium (Dark Theme)
echo   - Adds ^& Cuts (baseado em 440 decks reais)
echo   - Matchups Precisos (28-72%% range real)
echo   - Hand Analyzer com Shuffle
echo   - Deteccao de Arquetipo
echo.
echo Pressione qualquer tecla para sair...
pause >nul
exit /b 0

:error_backend
echo.
echo ERRO ao copiar arquivos do backend
echo Verifique se a pasta backend\services\ai existe
pause
exit /b 1

:error_frontend
echo.
echo ERRO ao copiar arquivos do frontend
echo Verifique se a pasta frontend\src existe
pause
exit /b 1
