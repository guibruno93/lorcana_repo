# 📦 LORCANA AI v3.0 - Lista Completa de Arquivos

## 🎯 RESUMO EXECUTIVO

Você tem **12 arquivos** para instalar o sistema completo:

### 📁 Arquivos principais (instalar PRIMEIRO):

| # | Arquivo | Destino | Obrigatório |
|---|---------|---------|-------------|
| 1 | `server.js` | `backend/server.js` | ✅ **SIM** |
| 2 | `routes-deck.js` | `backend/routes/deck.js` | ✅ **SIM** |
| 3 | `routes-ai-updated.js` | `backend/routes/ai.js` | ✅ **SIM** |
| 4 | `metaComparator-v2.js` | `backend/parser/metaComparator.js` | ✅ **SIM** |
| 5 | `matchupAnalyzer-v2.js` | `backend/services/ai/matchupAnalyzer.js` | ✅ **SIM** |
| 6 | `App.jsx` | `frontend/src/App.jsx` | ✅ **SIM** |
| 7 | `styles.css` | `frontend/src/styles.css` | ✅ **SIM** |

### 🛠️ Arquivos de suporte:

| # | Arquivo | Uso |
|---|---------|-----|
| 8 | `test-backend.js` | Testar se backend funciona |
| 9 | `INSTALL.bat` | Instalação automática (Windows) |
| 10 | `SOLUCAO-DEFINITIVA.md` | Guia passo-a-passo para erro req.body |
| 11 | `TROUBLESHOOTING.md` | Guia de erros comuns |
| 12 | `INSTALL.md` | Documentação técnica |

---

## ⚡ Instalação Rápida (Método 1 - Automático)

```powershell
# 1. Baixar TODOS os 12 arquivos na pasta raiz do projeto
cd S:\INKREC\lorcana_ai

# 2. Executar instalador
INSTALL.bat

# 3. Iniciar backend
cd backend
npm start

# 4. Iniciar frontend (OUTRO terminal)
cd frontend
npm start
```

---

## 🔧 Instalação Manual (Método 2)

### PASSO 1: Parar processos

```powershell
taskkill /F /IM node.exe
```

### PASSO 2: Backend (5 arquivos)

```powershell
cd S:\INKREC\lorcana_ai

copy /Y server.js backend\server.js
copy /Y routes-deck.js backend\routes\deck.js
copy /Y routes-ai-updated.js backend\routes\ai.js
copy /Y metaComparator-v2.js backend\parser\metaComparator.js
copy /Y matchupAnalyzer-v2.js backend\services\ai\matchupAnalyzer.js
```

### PASSO 3: Frontend (2 arquivos)

```powershell
copy /Y App.jsx frontend\src\App.jsx
copy /Y styles.css frontend\src\styles.css
```

### PASSO 4: Testar backend

```powershell
copy /Y test-backend.js backend\test-backend.js

cd backend
npm start
```

**DEVE mostrar:**
```
✅ Deck router carregado: /api/deck
✅ AI router carregado: /api/ai
```

### PASSO 5: Validar (IMPORTANTE!)

**Em OUTRO terminal:**

```powershell
cd backend
node test-backend.js
```

**Resultado esperado:**
```
✅ ALL TESTS PASSED
```

**Se falhar**, leia `SOLUCAO-DEFINITIVA.md`

### PASSO 6: Iniciar frontend

```powershell
cd frontend
npm start
```

---

## ❌ SE DER ERRO "req.body undefined"

**LEIA IMEDIATAMENTE: `SOLUCAO-DEFINITIVA.md`**

Esse arquivo tem o passo-a-passo GARANTIDO para corrigir.

**Causa comum:**
- `server.js` antigo ainda está sendo usado
- `routes/deck.js` não foi copiado

**Solução rápida:**
```powershell
# 1. Matar todos os processos Node
taskkill /F /IM node.exe

# 2. Recopiar server.js
copy /Y server.js backend\server.js

# 3. Recopiar routes
copy /Y routes-deck.js backend\routes\deck.js

# 4. Testar
cd backend
npm start
# DEVE mostrar: ✅ Deck router carregado

node test-backend.js
# DEVE mostrar: ✅ ALL TESTS PASSED
```

---

## 📊 O que cada arquivo faz

### `server.js`
- Registra a rota `/api/deck/analyze` (NOVA)
- Configura `express.json()` para receber body
- Carrega routers de deck e AI

### `routes-deck.js`
- Define `POST /api/deck/analyze`
- Chama `analyzeDeck()` + `compareWithMeta()`
- Retorna análise + adds/cuts

### `metaComparator-v2.js`
- Compara deck com 440 decks de torneio
- Calcula similaridade Jaccard
- Gera adds (cartas para adicionar)
- Gera cuts (cartas para remover)

### `matchupAnalyzer-v2.js`
- Detecta arquétipo do deck
- Matriz de matchup calibrada (8 arquétipos)
- Winrate 28-72% (range real)
- Ajustes por cartas específicas

### `App.jsx`
- UI completa com tabs
- Deck Analyzer + Hand Analyzer + Matchups
- Design premium dark theme

### `styles.css`
- Design system completo
- Dark theme (`#0d0e14`)
- Tipografia DM Sans + DM Mono
- Componentes padronizados

### `test-backend.js`
- Testa se backend está funcionando
- Valida endpoints `/api/deck/analyze`, `/api/ai/matchups`, etc.
- **SEMPRE execute antes de testar no frontend**

---

## ✅ Checklist de validação

Antes de dizer "não funciona", faça:

```powershell
cd S:\INKREC\lorcana_ai

# ✅ Arquivos existem?
dir backend\server.js
dir backend\routes\deck.js
dir backend\parser\metaComparator.js
dir frontend\src\App.jsx

# ✅ Server.js tem as rotas?
type backend\server.js | findstr "Deck router"

# ✅ Backend rodando?
curl http://localhost:5000/api/health

# ✅ Endpoints funcionam?
cd backend
node test-backend.js
```

**TODOS devem ser ✅**

---

## 🎁 Features instaladas

Após instalação completa, você terá:

### 🎨 Visual
- ✅ Dark theme profissional
- ✅ Tabs limpas (Deck / Hand / Matchups)
- ✅ Badges por cor de ink
- ✅ Design system padronizado

### ✂️ Adds & Cuts
- ✅ Compara com 440 decks reais
- ✅ Prioridade High/Medium/Low
- ✅ Frequência ponderada por colocação
- ✅ Sugestões específicas por carta

### ⚔️ Matchups
- ✅ Winrate real (28-72%)
- ✅ 8 arquétipos do meta
- ✅ Ajustes por cartas específicas
- ✅ Tips estratégicos por matchup

### 🎴 Hand Analyzer
- ✅ Shuffle hand do deck
- ✅ Mulligan inteligente (baseado em efeitos)
- ✅ Simulate mulligan
- ✅ Análise carta por carta

---

## 📞 Suporte

Se algo der errado:

1. ✅ Leia `SOLUCAO-DEFINITIVA.md` primeiro
2. ✅ Execute `test-backend.js`
3. ✅ Leia `TROUBLESHOOTING.md`
4. ✅ Verifique logs do backend (procure ❌ ou ⚠️)
5. ✅ Verifique console do browser (F12)

---

## 🚀 Próximos passos após instalação

1. **Testar Deck Analyzer**
   - Cole decklist → Analisar
   - Verificar adds/cuts
   - Ver decks similares

2. **Testar Matchups**
   - Ir na tab Matchups
   - Ver winrates (NÃO deve ser tudo 50%)
   - Ler key tips

3. **Testar Hand Analyzer**
   - Tab Hand Analyzer
   - Shuffle hand
   - Analyze hand
   - Ver mulligan suggestions
   - Simulate mulligan

**Tudo funcionando = sistema pronto!** 🎉

---

**Versão:** 3.0 Premium Edition  
**Data:** 2026-02-18  
**Arquivos:** 12 no total (7 principais + 5 suporte)
