# Instalação — Visual Upgrade + Adds/Cuts + Matchups Precisos

## Arquivos para copiar

### Frontend (2 arquivos)
```
App.jsx      → frontend/src/App.jsx        (substitui App.js)
styles.css   → frontend/src/styles.css     (substitui styles.css)
```

### Backend (4 arquivos)
```
metaComparator-v2.js   → backend/parser/metaComparator.js
matchupAnalyzer-v2.js  → backend/services/ai/matchupAnalyzer.js
routes-deck.js         → backend/routes/deck.js        (NOVO)
routes-ai-updated.js   → backend/routes/ai.js
```

## Registrar a rota /api/deck no server.js

No `backend/server.js`, adicione **uma linha**:

```js
// Adicionar junto com as outras rotas:
app.use('/api/deck', require('./routes/deck'));
```

## Comandos

```powershell
# Backend
cd S:\INKREC\lorcana_ai\backend
npm start

# Frontend
cd S:\INKREC\lorcana_ai\frontend
npm start
```

## O que foi criado

| Feature | Detalhes |
|---------|----------|
| **Adds & Cuts** | Compara seu deck com os 440 decks de torneio. Frequência ponderada por colocação (1° vale mais que TOP32). |
| **Matchups precisos** | Matriz calibrada com 8 arquétipos do meta. WR varia por cartas específicas (Be Prepared, Goliath, etc.). Range realista 28–72%. |
| **Detecção de arquétipo** | Identifica Blurple, Dogs, Ramp, Aggro, etc. por cartas-chave e inks. |
| **UI premium** | Dark theme, DM Sans/DM Mono, tabs, badges por ink, barra de WR. Sem amadorismo. |
| **Adds**: prioridade | High = +75% dos meta decks. Medium = 55–75%. Low = 45–55%. |
| **Cuts**: prioridade | High = <10% dos meta decks. Medium = 10–20%. |

## Lógica dos Adds & Cuts

O sistema:
1. Filtra os decks por `standing ≤ top` (default top-32)
2. Calcula similaridade Jaccard com seu deck
3. Pesa cada deck por colocação × similaridade
4. Cards com presença ≥45% no pool e você usa menos → **Add**
5. Cards que você usa mas aparecem em <30% do pool → **Cut**

## Matchup WR

Winrate não fica mais 50% em tudo:
- Ramp vs Aggro → 37% (correto — ramp perde para aggro)
- Aggro vs Ramp → 63%
- Blurple vs Control → 58%
- Ajustes por cartas: Be Prepared +4% vs Aggro, Goliath +3% vs Ramp, etc.
