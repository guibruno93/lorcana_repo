'use strict';

/**
 * routes/ai-SECURE.js
 * Versão segura com validações completas para endpoints de IA
 */

const express = require('express');
const router = express.Router();

// ── Validators ───────────────────────────────────────────────────────────────

function validateDecklist(decklist, res) {
  if (!decklist || typeof decklist !== 'string') {
    res.status(400).json({ 
      error: 'Invalid decklist',
      code: 'INVALID_DECKLIST' 
    });
    return false;
  }

  if (decklist.length > 50000) {
    res.status(400).json({ 
      error: 'Decklist too large',
      code: 'DECKLIST_TOO_LARGE' 
    });
    return false;
  }

  return true;
}

function validateHand(hand, res) {
  if (!Array.isArray(hand)) {
    res.status(400).json({ 
      error: 'Hand must be an array',
      code: 'INVALID_HAND_TYPE' 
    });
    return false;
  }

  if (hand.length !== 7) {
    res.status(400).json({ 
      error: 'Hand must have exactly 7 cards',
      code: 'INVALID_HAND_SIZE' 
    });
    return false;
  }

  for (let i = 0; i < hand.length; i++) {
    const card = hand[i];
    
    if (typeof card !== 'string') {
      res.status(400).json({ 
        error: `Card ${i+1} must be a string`,
        code: 'INVALID_CARD_TYPE' 
      });
      return false;
    }

    if (card.length > 200) {
      res.status(400).json({ 
        error: `Card ${i+1} name is too long`,
        code: 'CARD_NAME_TOO_LONG' 
      });
      return false;
    }
  }

  return true;
}

function sanitizeHand(hand) {
  return hand.map(card => 
    String(card)
      .replace(/<[^>]+>/g, '')
      .trim()
      .slice(0, 200)
  );
}

// ── Matchups ─────────────────────────────────────────────────────────────────

router.post('/matchups', async (req, res) => {
  try {
    const { decklist } = req.body;

    if (!validateDecklist(decklist, res)) return;

    const { analyzeMatchups } = require('../services/ai/matchupAnalyzer');
    const result = await analyzeMatchups(decklist);

    res.json(result);

  } catch (err) {
    console.error('Matchups error:', err);
    res.status(500).json({ 
      error: 'Failed to analyze matchups',
      code: 'MATCHUPS_ERROR' 
    });
  }
});

// ── Shuffle ──────────────────────────────────────────────────────────────────

// Cache curto para evitar duplicações
const shuffleCache = new Map();
const CACHE_TTL = 2000; // 2 segundos

function cleanupCache() {
  const now = Date.now();
  for (const [key, value] of shuffleCache.entries()) {
    if (now - value.timestamp > CACHE_TTL) {
      shuffleCache.delete(key);
    }
  }
}

// Limpar cache a cada 30 segundos
setInterval(cleanupCache, 30000);

router.post('/shuffle', async (req, res) => {
  try {
    const { decklist } = req.body;

    if (!validateDecklist(decklist, res)) return;

    // Verificar cache
    const cacheKey = decklist.slice(0, 100); // Usar primeiros 100 chars como key
    const cached = shuffleCache.get(cacheKey);

    if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
      return res.json(cached.data);
    }

    const { shuffleService } = require('../services/ai/shuffleService');
    const hand = await shuffleService(decklist);

    const response = { hand };
    shuffleCache.set(cacheKey, {
      data: response,
      timestamp: Date.now(),
    });

    res.json(response);

  } catch (err) {
    console.error('Shuffle error:', err);
    res.status(500).json({ 
      error: 'Failed to shuffle deck',
      code: 'SHUFFLE_ERROR' 
    });
  }
});

// ── Mulligan ─────────────────────────────────────────────────────────────────

router.post('/mulligan', async (req, res) => {
  try {
    const { hand, decklist } = req.body;

    if (!validateHand(hand, res)) return;
    if (!validateDecklist(decklist, res)) return;

    const sanitizedHand = sanitizeHand(hand);

    const { analyzeMulligan } = require('../services/ai/mulliganAdvisor');
    const result = await analyzeMulligan(sanitizedHand, decklist);

    res.json(result);

  } catch (err) {
    console.error('Mulligan error:', err);
    res.status(500).json({ 
      error: 'Failed to analyze mulligan',
      code: 'MULLIGAN_ERROR' 
    });
  }
});

// ── Simulate Mulligan ────────────────────────────────────────────────────────

router.post('/simulate-mulligan', async (req, res) => {
  try {
    const { hand, mulligan, decklist } = req.body;

    if (!validateHand(hand, res)) return;
    if (!validateDecklist(decklist, res)) return;

    // Validar índices de mulligan
    if (!Array.isArray(mulligan)) {
      return res.status(400).json({ 
        error: 'Mulligan must be an array of indices',
        code: 'INVALID_MULLIGAN' 
      });
    }

    for (const idx of mulligan) {
      if (!Number.isInteger(idx) || idx < 0 || idx >= 7) {
        return res.status(400).json({ 
          error: 'Invalid mulligan index',
          code: 'INVALID_MULLIGAN_INDEX' 
        });
      }
    }

    const { simulateMulligan } = require('../services/ai/mulliganAdvisor');
    const newHand = await simulateMulligan(hand, mulligan, decklist);

    res.json({ hand: newHand });

  } catch (err) {
    console.error('Simulate mulligan error:', err);
    res.status(500).json({ 
      error: 'Failed to simulate mulligan',
      code: 'SIMULATE_ERROR' 
    });
  }
});

// ── Health Check ─────────────────────────────────────────────────────────────

router.get('/health', (req, res) => {
  res.json({ 
    ok: true,
    service: 'ai',
    version: '4.3',
    cacheSize: shuffleCache.size,
  });
});

module.exports = router;
