# 🔍 AUDITORIA COMPLETA - Lorcana AI v4.3

## 📋 ESCOPO DA AUDITORIA

Análise de **segurança, estabilidade e performance** em todos os componentes:

✅ Backend (5 arquivos principais)  
✅ Frontend (3 arquivos principais)  
✅ API Routes (3 arquivos)  
✅ Services (3 arquivos)  

---

## 🐛 BUGS IDENTIFICADOS & CORREÇÕES

### **1. BACKEND - server.js**

#### **Bug 1.1: Falta de rate limiting**
**Risco:** DoS attacks, abuse  
**Impacto:** Alto  

**Problema:**
```javascript
// Nenhuma proteção contra requests em massa
app.post('/api/deck/analyze', ...)
```

**Correção:**
```javascript
// Adicionar express-rate-limit
const rateLimit = require('express-rate-limit');

const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  max: 100, // 100 requests por IP
  message: 'Too many requests, please try again later.'
});

app.use('/api/', apiLimiter);
```

#### **Bug 1.2: Sem timeout em requests**
**Risco:** Requests pendurados, memory leak  
**Impacto:** Médio  

**Problema:**
```javascript
// Request pode ficar pendurado indefinidamente
app.post('/api/deck/analyze', async (req, res) => {
  await analyzeDeck(...); // Sem timeout
});
```

**Correção:**
```javascript
// Adicionar timeout
app.use((req, res, next) => {
  req.setTimeout(30000); // 30s timeout
  next();
});
```

#### **Bug 1.3: Error handling genérico**
**Risco:** Leaking internal errors  
**Impacto:** Baixo  

**Problema:**
```javascript
catch(err) {
  res.status(500).json({ error: err.message }); // Pode expor stack trace
}
```

**Correção:**
```javascript
catch(err) {
  console.error('Internal error:', err);
  res.status(500).json({ 
    error: 'Internal server error',
    code: 'INTERNAL_ERROR' 
  });
}
```

---

### **2. BACKEND - routes/deck.js**

#### **Bug 2.1: Sem validação de input**
**Risco:** Injection attacks, crashes  
**Impacto:** Alto  

**Problema:**
```javascript
const { decklist } = req.body;
await analyzeDeck(decklist); // Sem validação
```

**Correção:**
```javascript
const { decklist, compare, top, sameFormat } = req.body;

// Validar decklist
if (!decklist || typeof decklist !== 'string') {
  return res.status(400).json({ error: 'Invalid decklist' });
}

if (decklist.length > 10000) {
  return res.status(400).json({ error: 'Decklist too large' });
}

// Validar top
if (top && (typeof top !== 'number' || top < 1 || top > 128)) {
  return res.status(400).json({ error: 'Invalid top value' });
}
```

#### **Bug 2.2: Sem sanitização**
**Risco:** XSS, code injection  
**Impacto:** Médio  

**Problema:**
```javascript
// Decklist pode conter scripts maliciosos
const decklist = req.body.decklist;
```

**Correção:**
```javascript
function sanitizeDecklist(decklist) {
  return decklist
    .replace(/<script[^>]*>.*?<\/script>/gi, '')
    .replace(/<[^>]+>/g, '')
    .trim();
}

const decklist = sanitizeDecklist(req.body.decklist);
```

---

### **3. BACKEND - routes/ai.js**

#### **Bug 3.1: Falta de validação de hand**
**Risco:** Crash com hand inválido  
**Impacto:** Médio  

**Problema:**
```javascript
const { hand } = req.body;
await mulligan(hand); // Sem validar tamanho/conteúdo
```

**Correção:**
```javascript
const { hand, decklist } = req.body;

// Validar hand
if (!Array.isArray(hand)) {
  return res.status(400).json({ error: 'Hand must be an array' });
}

if (hand.length !== 7) {
  return res.status(400).json({ error: 'Hand must have exactly 7 cards' });
}

// Validar cada carta
for (const card of hand) {
  if (typeof card !== 'string' || card.length > 100) {
    return res.status(400).json({ error: 'Invalid card in hand' });
  }
}
```

#### **Bug 3.2: Race condition no shuffle**
**Risco:** Shuffle duplicado se usuário clica múltiplas vezes  
**Impacto:** Baixo  

**Problema:**
```javascript
// Sem proteção contra requests concorrentes
app.post('/api/ai/shuffle', async (req, res) => {
  const hand = await shuffle(deck);
  res.json({ hand });
});
```

**Correção:**
```javascript
// Adicionar idempotency key ou debounce no frontend
// Frontend já tem loading state, mas backend pode adicionar cache curto
const shuffleCache = new Map();

app.post('/api/ai/shuffle', async (req, res) => {
  const key = req.body.decklist;
  const cached = shuffleCache.get(key);
  
  if (cached && Date.now() - cached.timestamp < 1000) {
    return res.json(cached.data);
  }
  
  const hand = await shuffle(deck);
  shuffleCache.set(key, { data: { hand }, timestamp: Date.now() });
  
  res.json({ hand });
});
```

---

### **4. SERVICES - metaAnalyzer.js**

#### **Bug 4.1: Division by zero**
**Risco:** Crash com decks vazios  
**Impacto:** Médio  

**Problema:**
```javascript
const weekPct = (weekData.count / weekTotal) * 100; // Se weekTotal = 0
```

**Correção:**
```javascript
const weekTotal = week._total || 1; // Evita divisão por 0
const weekPct = weekTotal > 0 ? (weekData.count / weekTotal) * 100 : 0;
```

#### **Bug 4.2: Memory leak com arrays grandes**
**Risco:** Consumo excessivo de memória  
**Impacto:** Médio  

**Problema:**
```javascript
// Carrega todos os decks na memória
const decks = JSON.parse(fs.readFileSync(DB_PATH));
```

**Correção:**
```javascript
// Limitar tamanho ou usar streaming para arquivos grandes
const MAX_DECKS = 10000;
let decks = JSON.parse(fs.readFileSync(DB_PATH));

if (decks.length > MAX_DECKS) {
  console.warn(`Limiting to ${MAX_DECKS} decks for performance`);
  decks = decks.slice(0, MAX_DECKS);
}
```

---

### **5. SERVICES - cardUpdater.js**

#### **Bug 5.1: Sem retry em falha de rede**
**Risco:** Update falha permanentemente  
**Impacto:** Médio  

**Problema:**
```javascript
const remoteCards = await fetchJSON(url); // Falha = fim
```

**Correção:**
```javascript
async function fetchWithRetry(url, retries = 3) {
  for (let i = 0; i < retries; i++) {
    try {
      return await fetchJSON(url);
    } catch (err) {
      if (i === retries - 1) throw err;
      await sleep(1000 * (i + 1)); // Backoff exponencial
    }
  }
}
```

#### **Bug 5.2: Sem validação de resposta**
**Risco:** Corrupted data entra no DB  
**Impacto:** Alto  

**Problema:**
```javascript
const remoteCards = await fetchJSON(url);
// Não valida se é array válido
```

**Correção:**
```javascript
const remoteCards = await fetchJSON(url);

// Validar resposta
if (!Array.isArray(remoteCards) || remoteCards.length === 0) {
  throw new Error('Invalid response: expected non-empty array');
}

// Validar cada card
for (const card of remoteCards) {
  if (!card.name || !card.id) {
    console.warn(`Skipping invalid card: ${JSON.stringify(card)}`);
    continue;
  }
}
```

---

### **6. FRONTEND - App.jsx**

#### **Bug 6.1: Estado não limpo entre tabs**
**Risco:** Dados antigos aparecem em nova tab  
**Impacto:** Baixo  

**Problema:**
```javascript
// Mudar de tab não limpa estado anterior
setTab("matchups"); // Dados do deck analyzer ainda visíveis
```

**Correção:**
```javascript
function changeTab(newTab) {
  // Limpar estados relevantes ao mudar de tab
  if (newTab !== tab) {
    setError('');
    // Adicionar outros estados conforme necessário
  }
  setTab(newTab);
}
```

#### **Bug 6.2: Memory leak com useEffect**
**Risco:** Requests não cancelados ao desmontar  
**Impacto:** Baixo  

**Problema:**
```javascript
useEffect(() => {
  fetch('/api/data').then(setData);
}, []); // Sem cleanup
```

**Correção:**
```javascript
useEffect(() => {
  let cancelled = false;
  
  fetch('/api/data')
    .then(data => {
      if (!cancelled) setData(data);
    });
  
  return () => { cancelled = true; };
}, []);
```

#### **Bug 6.3: Sem debounce em inputs**
**Risco:** Muitos requests ao digitar  
**Impacto:** Baixo  

**Problema:**
```javascript
// Cada tecla pode triggerar análise
onChange={e => analyze(e.target.value)}
```

**Correção:**
```javascript
// Adicionar debounce
const debouncedAnalyze = useMemo(
  () => debounce(analyze, 500),
  []
);

onChange={e => debouncedAnalyze(e.target.value)}
```

---

### **7. FRONTEND - MetaDashboard.jsx**

#### **Bug 7.1: Sem loading mínimo**
**Risco:** Flash de loading (UX ruim)  
**Impacto:** Baixo  

**Problema:**
```javascript
// Loading pode ser < 100ms, causando flash
setLoading(true);
await fetch(...);
setLoading(false);
```

**Correção:**
```javascript
const MIN_LOADING_TIME = 300; // ms

async function fetchMetaState() {
  setLoading(true);
  const start = Date.now();
  
  try {
    const res = await fetch(...);
    const elapsed = Date.now() - start;
    
    if (elapsed < MIN_LOADING_TIME) {
      await sleep(MIN_LOADING_TIME - elapsed);
    }
    
    setData(res);
  } finally {
    setLoading(false);
  }
}
```

#### **Bug 7.2: Sem tratamento de data corrompida**
**Risco:** Crash ao renderizar dados inválidos  
**Impacto:** Médio  

**Problema:**
```javascript
{data.archetypes.map(a => <div>{a.weekShare}%</div>)}
// Se weekShare é null/undefined/NaN
```

**Correção:**
```javascript
{data.archetypes.map(a => (
  <div>
    {isFinite(a.weekShare) ? a.weekShare : 0}%
  </div>
))}

// Ou adicionar validação antes:
function validateArchetype(arch) {
  return {
    ...arch,
    weekShare: isFinite(arch.weekShare) ? arch.weekShare : 0,
    weekCount: Math.max(0, arch.weekCount || 0),
    change: isFinite(arch.change) ? arch.change : 0,
  };
}

const validArchetypes = data.archetypes.map(validateArchetype);
```

---

### **8. GERAL - Error Boundaries**

#### **Bug 8.1: Sem Error Boundary**
**Risco:** App inteiro quebra com erro em componente  
**Impacto:** Alto  

**Problema:**
```javascript
// Nenhum Error Boundary implementado
<MetaDashboard /> // Se quebrar, quebra tudo
```

**Correção:**
```javascript
// Criar ErrorBoundary.jsx
class ErrorBoundary extends React.Component {
  state = { hasError: false, error: null };
  
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  
  componentDidCatch(error, errorInfo) {
    console.error('Error boundary caught:', error, errorInfo);
  }
  
  render() {
    if (this.state.hasError) {
      return (
        <div className="error-boundary">
          <h2>Something went wrong</h2>
          <button onClick={() => window.location.reload()}>
            Reload
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

// Usar no App.jsx
<ErrorBoundary>
  <MetaDashboard />
</ErrorBoundary>
```

---

## 📊 RESUMO DE BUGS

| Categoria | Total | Alto | Médio | Baixo |
|-----------|-------|------|-------|-------|
| Backend | 8 | 2 | 5 | 1 |
| Frontend | 6 | 1 | 2 | 3 |
| **TOTAL** | **14** | **3** | **7** | **4** |

---

## 🎯 PRIORIDADE DE CORREÇÃO

### **Prioridade 1 (ALTA) - Implementar AGORA**
1. ✅ Input validation (routes/deck.js, routes/ai.js)
2. ✅ Data validation (cardUpdater.js)
3. ✅ Error Boundary (App.jsx)

### **Prioridade 2 (MÉDIA) - Implementar esta semana**
4. ⚠️ Rate limiting (server.js)
5. ⚠️ Request timeout (server.js)
6. ⚠️ Retry logic (cardUpdater.js)
7. ⚠️ Memory limits (metaAnalyzer.js)
8. ⚠️ Data sanitization (routes/deck.js)

### **Prioridade 3 (BAIXA) - Nice to have**
9. 💡 Debounce inputs (App.jsx)
10. 💡 Loading minimum time (MetaDashboard.jsx)
11. 💡 Request cancellation (App.jsx)
12. 💡 State cleanup (App.jsx)

---

## 🔧 PRÓXIMO PASSO

Vou criar arquivos FIXED com todas as correções de Prioridade 1 implementadas:

1. **routes-deck-SECURE.js** - Com validações completas
2. **routes-ai-SECURE.js** - Com validações completas
3. **cardUpdater-SECURE.js** - Com retry e validação
4. **ErrorBoundary.jsx** - Componente novo
5. **App-SECURE.jsx** - Com Error Boundary

**Quer que eu crie esses arquivos agora?** 🔧
